// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"or4r":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"WEtf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"RZIL":[function(require,module,exports) {
var define;
"use strict";!function(e){"function"==typeof define&&define.amd?define(e):"undefined"!=typeof module&&module.exports?module.exports=e():window.enterView=e.call(this)}(function(){var e=function(e){function n(){E=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.msRequestAnimationFrame||function(e){return setTimeout(e,1e3/60)}}function t(){if(y&&"number"==typeof y){var e=Math.min(Math.max(0,y),1);return F-e*F}return F}function o(){var e=document.documentElement.clientHeight,n=window.innerHeight||0;F=Math.max(e,n)}function r(){L=!1;var e=t();M=M.filter(function(n){var t=n.getBoundingClientRect(),o=t.top,r=t.bottom,i=t.height,s=o<e,u=r<e;if(s&&!n.__ev_entered){if(m(n),n.__ev_progress=0,h(n,n.__ev_progress),q)return!1}else!s&&n.__ev_entered&&(n.__ev_progress=0,h(n,n.__ev_progress),g(n));if(s&&!u){var d=(e-o)/i;n.__ev_progress=Math.min(1,Math.max(0,d)),h(n,n.__ev_progress)}return s&&u&&1!==n.__ev_progress&&(n.__ev_progress=1,h(n,n.__ev_progress)),n.__ev_entered=s,!0}),M.length||window.removeEventListener("scroll",i,!0)}function i(){L||(L=!0,E(r))}function s(){o(),r()}function u(){o(),r()}function d(e){for(var n=e.length,t=[],o=0;o<n;o+=1)t.push(e[o]);return t}function f(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:document;return"string"==typeof e?d(n.querySelectorAll(e)):e instanceof NodeList?d(e):e instanceof Array?e:void 0}function c(){M=f(v)}function a(){window.addEventListener("resize",s,!0),window.addEventListener("scroll",i,!0),window.addEventListener("load",u,!0),s()}function _(){return v?(c(),M&&M.length?(n(),a(),void r()):(console.error("no selector elements found"),!1)):(console.error("must pass a selector"),!1)}var v=e.selector,l=e.enter,m=void 0===l?function(){}:l,w=e.exit,g=void 0===w?function(){}:w,p=e.progress,h=void 0===p?function(){}:p,x=e.offset,y=void 0===x?0:x,A=e.once,q=void 0!==A&&A,E=null,L=!1,M=[],F=0;_()};return e});
},{}],"xZJw":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = loadData;

/* global d3 */

/* usage
	import loadData from './load-data'
	
	loadData('file.csv').then(result => {
		console.log(result);
	}).catch(console.error);

	loadData(['file1.csv', 'file2.json]).then(result => {
		console.log(result);
	}).catch(console.error);
*/
function loadFile(file) {
  return new Promise(function (resolve, reject) {
    var ext = file.split('.').pop();
    if (ext === 'csv') d3.csv("assets/data/".concat(file)).then(resolve).catch(reject);else if (ext === 'json') d3.json("assets/data/".concat(file)).then(resolve).catch(reject);else reject(new Error("unsupported file type for: ".concat(file)));
  });
}

function loadData(files) {
  if (typeof files === 'string') return loadFile(files);
  var loads = files.map(loadFile);
  return Promise.all(loads);
}
},{}],"flIy":[function(require,module,exports) {
module.exports = {
  ".DS_S": ".DS_Store",
  "1790_1": "1790_1.png",
  "1790_2": "1790_2.png",
  "1790_3-4": "1790_3-4.png",
  "1790_5": "1790_5.png",
  "1790_6": "1790_6.png",
  "1790_7": "1790_7.png",
  "1800_1": "1800_1.png",
  "1800_12": "1800_12-1800_13.png",
  "1800_13": "1800_12-1800_13.png",
  "1800_2-6": "1800_2-6.png",
  "1800_7-11": "1800_7-11.png",
  "1810_1": "1810_1.png",
  "1810_12": "1810_12.png",
  "1810_2-6": "1810_2-6.png",
  "1810_7-11": "1810_7-11.png",
  "1820_1": "1820_1.png",
  "1820_2-6": "1820_2-6.png",
  "1820_28": "1820_28.png",
  "1820_29": "1820_29.png",
  "1820_30": "1820_30.png",
  "1820_31": "1820_31.png",
  "1820_7-11": "1820_7-11.png",
  "1830_1": "1830_1.png",
  "1830_15-27": "1830_15-27.png",
  "1830_2-14": "1830_2-14.png",
  "1830_28-33": "1830_28-33.png",
  "1830_34-39": "1830_34-39.png",
  "1830_40-45": "1830_40-45.png",
  "1830_46-51": "1830_46-51.png",
  "1830_52-54": "1830_52-54.png",
  "1830_55": "1830_55-1830_56.png",
  "1830_56": "1830_55-1830_56.png",
  "1830_57-59": "1830_57-59.png",
  "1830_60": "1830_60.png",
  "1840_1": "1840_1.png",
  "1840_15-27": "1840_15-27.png",
  "1840_2-14": "1840_2-14.png",
  "1840_28-33": "1840_28-33.png",
  "1840_34-39": "1840_34-39.png",
  "1840_40-45": "1840_40-45.png",
  "1840_46-51": "1840_46-51.png",
  "1840_52": "1840_52-1840_53-1840_54-1840_55-1840_56-1840_57-1840_58.png",
  "1840_53": "1840_52-1840_53-1840_54-1840_55-1840_56-1840_57-1840_58.png",
  "1840_54": "1840_52-1840_53-1840_54-1840_55-1840_56-1840_57-1840_58.png",
  "1840_55": "1840_52-1840_53-1840_54-1840_55-1840_56-1840_57-1840_58.png",
  "1840_56": "1840_52-1840_53-1840_54-1840_55-1840_56-1840_57-1840_58.png",
  "1840_57": "1840_52-1840_53-1840_54-1840_55-1840_56-1840_57-1840_58.png",
  "1840_58": "1840_52-1840_53-1840_54-1840_55-1840_56-1840_57-1840_58.png",
  "1840_59-60": "1840_59-60.png",
  "1840_61-63": "1840_61-63.png",
  "1840_64": "1840_64-1840_65-1840_66.png",
  "1840_65": "1840_64-1840_65-1840_66.png",
  "1840_66": "1840_64-1840_65-1840_66.png",
  "1840_67": "1840_67-1840_68-1840_69-1840_70.png",
  "1840_68": "1840_67-1840_68-1840_69-1840_70.png",
  "1840_69": "1840_67-1840_68-1840_69-1840_70.png",
  "1840_70": "1840_67-1840_68-1840_69-1840_70.png",
  "1840_71": "1840_71-1840_72-1840_73-1840_74-1840_75.png",
  "1840_72": "1840_71-1840_72-1840_73-1840_74-1840_75.png",
  "1840_73": "1840_71-1840_72-1840_73-1840_74-1840_75.png",
  "1840_74": "1840_71-1840_72-1840_73-1840_74-1840_75.png",
  "1840_75": "1840_71-1840_72-1840_73-1840_74-1840_75.png",
  "1850_10": "1850_10.png",
  "1850_11": "1850_11.png",
  "1850_12": "1850_12.png",
  "1850_13": "1850_13.png",
  "1850_3": "1850_3.png",
  "1850_4": "1850_4-1850_5-1850_6.png",
  "1850_5": "1850_4-1850_5-1850_6.png",
  "1850_6": "1850_4-1850_5-1850_6.png",
  "1850_7": "1850_7.png",
  "1850_8": "1850_8.png",
  "1850_9": "1850_9.png",
  "1860_10": "1860_10.png",
  "1860_11": "1860_11.png",
  "1860_12": "1860_12.png",
  "1860_13": "1860_13.png",
  "1860_14": "1860_14.png",
  "1860_3": "1860_3.png",
  "1860_4": "1860_4-1860_5-1860_6.png",
  "1860_5": "1860_4-1860_5-1860_6.png",
  "1860_6": "1860_4-1860_5-1860_6.png",
  "1860_7": "1860_7.png",
  "1860_8": "1860_8-1860_9.png",
  "1860_9": "1860_8-1860_9.png",
  "1870_10": "1870_10.png",
  "1870_11": "1870_11-1870_12.png",
  "1870_12": "1870_11-1870_12.png",
  "1870_13": "1870_13.png",
  "1870_14": "1870_14.png",
  "1870_15": "1870_15.png",
  "1870_16": "1870_16-1870_17.png",
  "1870_17": "1870_16-1870_17.png",
  "1870_18": "1870_18.png",
  "1870_19": "1870_19-1870_20.png",
  "1870_20": "1870_19-1870_20.png",
  "1870_3": "1870_3.png",
  "1870_4": "1870_4-1870_5-1870_6.png",
  "1870_5": "1870_4-1870_5-1870_6.png",
  "1870_6": "1870_4-1870_5-1870_6.png",
  "1870_7": "1870_7.png",
  "1870_8": "1870_8-1870_9.png",
  "1870_9": "1870_8-1870_9.png",
  "1880_12": "1880_12.png",
  "1880_13": "1880_13.png",
  "1880_14": "1880_14.png",
  "1880_15": "1880_15.png",
  "1880_16": "1880_16-1880_17-1880_18-1880_19-1880_20.png",
  "1880_17": "1880_16-1880_17-1880_18-1880_19-1880_20.png",
  "1880_18": "1880_16-1880_17-1880_18-1880_19-1880_20.png",
  "1880_19": "1880_16-1880_17-1880_18-1880_19-1880_20.png",
  "1880_20": "1880_16-1880_17-1880_18-1880_19-1880_20.png",
  "1880_21": "1880_21-1880_22-1880_23.png",
  "1880_22": "1880_21-1880_22-1880_23.png",
  "1880_23": "1880_21-1880_22-1880_23.png",
  "1880_24": "1880_24.png",
  "1880_25": "1880_25.png",
  "1880_26": "1880_26.png",
  "1880_3": "1880_3.png",
  "1880_4": "1880_4-1880_5-1880_6.png",
  "1880_5": "1880_4-1880_5-1880_6.png",
  "1880_6": "1880_4-1880_5-1880_6.png",
  "1880_7": "1880_7.png",
  "1880_8": "1880_8.png",
  "1880_9": "1880_9-1880_10-1880_11.png",
  "1880_10": "1880_9-1880_10-1880_11.png",
  "1880_11": "1880_9-1880_10-1880_11.png",
  "1890_1": "1890_1.png",
  "1890_10": "1890_10.png",
  "1890_11": "1890_11.png",
  "1890_12": "1890_12.png",
  "1890_13": "1890_13.png",
  "1890_14": "1890_14.png",
  "1890_15": "1890_15.png",
  "1890_16": "1890_16.png",
  "1890_17": "1890_17.png",
  "1890_18": "1890_18.png",
  "1890_19": "1890_19.png",
  "1890_2": "1890_2.png",
  "1890_20": "1890_20.png",
  "1890_21": "1890_21.png",
  "1890_22": "1890_22.png",
  "1890_23": "1890_23.png",
  "1890_24": "1890_24.png",
  "1890_26": "1890_26.png",
  "1890_27": "1890_27.png",
  "1890_28": "1890_28.png",
  "1890_29": "1890_29.png",
  "1890_3": "1890_3.png",
  "1890_30": "1890_30.png",
  "1890_4": "1890_4.png",
  "1890_5": "1890_5.png",
  "1890_6": "1890_6.png",
  "1890_7": "1890_7.png",
  "1890_8": "1890_8.png",
  "1890_9": "1890_9.png",
  "1900_11": "1900_11-1900_12.png",
  "1900_12": "1900_11-1900_12.png",
  "1900_13": "1900_13-1900_14-1900_15.png",
  "1900_14": "1900_13-1900_14-1900_15.png",
  "1900_15": "1900_13-1900_14-1900_15.png",
  "1900_16": "1900_16-1900_17-1900_18.png",
  "1900_17": "1900_16-1900_17-1900_18.png",
  "1900_18": "1900_16-1900_17-1900_18.png",
  "1900_19": "1900_19-1900_20.png",
  "1900_20": "1900_19-1900_20.png",
  "1900_21": "1900_21-1900_22-1900_23-1900_24.png",
  "1900_22": "1900_21-1900_22-1900_23-1900_24.png",
  "1900_23": "1900_21-1900_22-1900_23-1900_24.png",
  "1900_24": "1900_21-1900_22-1900_23-1900_24.png",
  "1900_25": "1900_25-1900_26-1900_27.png",
  "1900_26": "1900_25-1900_26-1900_27.png",
  "1900_27": "1900_25-1900_26-1900_27.png",
  "1900_3": "1900_3.png",
  "1900_4": "1900_4.png",
  "1900_5": "1900_5-1900_6.png",
  "1900_6": "1900_5-1900_6.png",
  "1900_7": "1900_7.png",
  "1900_8": "1900_8.png",
  "1900_9": "1900_9-1900_10.png",
  "1900_10": "1900_9-1900_10.png",
  "1910_10": "1910_10-1910_11.png",
  "1910_11": "1910_10-1910_11.png",
  "1910_12": "1910_12-1910_13-1910_14.png",
  "1910_13": "1910_12-1910_13-1910_14.png",
  "1910_14": "1910_12-1910_13-1910_14.png",
  "1910_15": "1910_15-1910_16.png",
  "1910_16": "1910_15-1910_16.png",
  "1910_17": "1910_17.png",
  "1910_18": "1910_18.png",
  "1910_19": "1910_19.png",
  "1910_20": "1910_20.png",
  "1910_21": "1910_21-1910_22.png",
  "1910_22": "1910_21-1910_22.png",
  "1910_23": "1910_23-1910_24-1910_25.png",
  "1910_24": "1910_23-1910_24-1910_25.png",
  "1910_25": "1910_23-1910_24-1910_25.png",
  "1910_26": "1910_26-1910_27-1910_28.png",
  "1910_27": "1910_26-1910_27-1910_28.png",
  "1910_28": "1910_26-1910_27-1910_28.png",
  "1910_3": "1910_3.png",
  "1910_30": "1910_30.png",
  "1910_31": "1910_31.png",
  "1910_32": "1910_32.png",
  "1910_4": "1910_4.png",
  "1910_5": "1910_5-1910_6.png",
  "1910_6": "1910_5-1910_6.png",
  "1910_7": "1910_7-1910_8-1910_9.png",
  "1910_8": "1910_7-1910_8-1910_9.png",
  "1910_9": "1910_7-1910_8-1910_9.png",
  "1920_13": "1920_13-1920_14-1920_15.png",
  "1920_14": "1920_13-1920_14-1920_15.png",
  "1920_15": "1920_13-1920_14-1920_15.png",
  "1920_16": "1920_16-1920_17-1920_18.png",
  "1920_17": "1920_16-1920_17-1920_18.png",
  "1920_18": "1920_16-1920_17-1920_18.png",
  "1920_19": "1920_19-1920_20.png",
  "1920_20": "1920_19-1920_20.png",
  "1920_21": "1920_21-1920_22.png",
  "1920_22": "1920_21-1920_22.png",
  "1920_23": "1920_23-1920_24.png",
  "1920_24": "1920_23-1920_24.png",
  "1920_25": "1920_25.png",
  "1920_26": "1920_26.png",
  "1920_27": "1920_27.png",
  "1920_28": "1920_28.png",
  "1920_5": "1920_5.png",
  "1920_6": "1920_6.png",
  "1920_7": "1920_7-1920_8.png",
  "1920_8": "1920_7-1920_8.png",
  "1920_9": "1920_9-1920_10-1920_11-1920_12.png",
  "1920_10": "1920_9-1920_10-1920_11-1920_12.png",
  "1920_11": "1920_9-1920_10-1920_11-1920_12.png",
  "1920_12": "1920_9-1920_10-1920_11-1920_12.png",
  "1930_11": "1930_11-1930_12-1930_13-1930_14-1930_15.png",
  "1930_12": "1930_11-1930_12-1930_13-1930_14-1930_15.png",
  "1930_13": "1930_11-1930_12-1930_13-1930_14-1930_15.png",
  "1930_14": "1930_11-1930_12-1930_13-1930_14-1930_15.png",
  "1930_15": "1930_11-1930_12-1930_13-1930_14-1930_15.png",
  "1930_16": "1930_16-1930_17.png",
  "1930_17": "1930_16-1930_17.png",
  "1930_18": "1930_18-1930_19-1930_20.png",
  "1930_19": "1930_18-1930_19-1930_20.png",
  "1930_20": "1930_18-1930_19-1930_20.png",
  "1930_21": "1930_21.png",
  "1930_22": "1930_22-1930_23-1930_24.png",
  "1930_23": "1930_22-1930_23-1930_24.png",
  "1930_24": "1930_22-1930_23-1930_24.png",
  "1930_25": "1930_25.png",
  "1930_26": "1930_26.png",
  "1930_27": "1930_27.png",
  "1930_28": "1930_28.png",
  "1930_30": "1930_30-1930_31.png",
  "1930_31": "1930_30-1930_31.png",
  "1930_5": "1930_5.png",
  "1930_6": "1930_6.png",
  "1930_7": "1930_7-1930_8-1930_9-1930_10.png",
  "1930_8": "1930_7-1930_8-1930_9-1930_10.png",
  "1930_9": "1930_7-1930_8-1930_9-1930_10.png",
  "1930_10": "1930_7-1930_8-1930_9-1930_10.png",
  "1940_13": "1940_13-1940_14.png",
  "1940_14": "1940_13-1940_14.png",
  "1940_15": "1940_15.png",
  "1940_16": "1940_16.png",
  "1940_17_18_19_20": "1940_17_18_19_20.png",
  "1940_21": "1940_21.png",
  "1940_22": "1940_22.png",
  "1940_23": "1940_23-1940_24.png",
  "1940_24": "1940_23-1940_24.png",
  "1940_25": "1940_25.png",
  "1940_26": "1940_26.png",
  "1940_27": "1940_27.png",
  "1940_28": "1940_28-1940_29-1940_30.png",
  "1940_29": "1940_28-1940_29-1940_30.png",
  "1940_30": "1940_28-1940_29-1940_30.png",
  "1940_31": "1940_31.png",
  "1940_32": "1940_32-1940_33.png",
  "1940_33": "1940_32-1940_33.png",
  "1940_36": "1940_36-1940_37.png",
  "1940_37": "1940_36-1940_37.png",
  "1940_38": "1940_38.png",
  "1940_39": "1940_39-1940_40-1940_41.png",
  "1940_40": "1940_39-1940_40-1940_41.png",
  "1940_41": "1940_39-1940_40-1940_41.png",
  "1940_4": "1940_4-1940_5-1940_6.png",
  "1940_5": "1940_4-1940_5-1940_6.png",
  "1940_6": "1940_4-1940_5-1940_6.png",
  "1940_42": "1940_42-1940_43-1940_44.png",
  "1940_43": "1940_42-1940_43-1940_44.png",
  "1940_44": "1940_42-1940_43-1940_44.png",
  "1940_45": "1940_45-1940_46-1940_47.png",
  "1940_46": "1940_45-1940_46-1940_47.png",
  "1940_47": "1940_45-1940_46-1940_47.png",
  "1940_48": "1940_48-1940_49-1940_50.png",
  "1940_49": "1940_48-1940_49-1940_50.png",
  "1940_50": "1940_48-1940_49-1940_50.png",
  "1940_7": "1940_7.png",
  "1940_8": "1940_8.png",
  "1940_9": "1940_9-1940_10-1940_11-1940_12.png",
  "1940_10": "1940_9-1940_10-1940_11-1940_12.png",
  "1940_11": "1940_9-1940_10-1940_11-1940_12.png",
  "1940_12": "1940_9-1940_10-1940_11-1940_12.png",
  "1940_H": "1940_H.png",
  "1950_10": "1950_10.png",
  "1950_11": "1950_11.png",
  "1950_12": "1950_12.png",
  "1950_13": "1950_13.png",
  "1950_14": "1950_14.png",
  "1950_15": "1950_15.png",
  "1950_16": "1950_16.png",
  "1950_17": "1950_17.png",
  "1950_18": "1950_18.png",
  "1950_19": "1950_19.png",
  "1950_20a": "1950_20a-1950_20b-1950_20c.png",
  "1950_20b": "1950_20a-1950_20b-1950_20c.png",
  "1950_20c": "1950_20a-1950_20b-1950_20c.png",
  "1950_21": "1950_21.png",
  "1950_22": "1950_22-1950_23.png",
  "1950_23": "1950_22-1950_23.png",
  "1950_24": "1950_24.png",
  "1950_25i": "1950_25i-1950_25ii.png",
  "1950_25ii": "1950_25i-1950_25ii.png",
  "1950_26": "1950_26.png",
  "1950_27": "1950_27.png",
  "1950_28": "1950_28.png",
  "1950_29": "1950_29.png",
  "1950_30": "1950_30.png",
  "1950_31a": "1950_31a-1950_31b-1950_31c.png",
  "1950_31b": "1950_31a-1950_31b-1950_31c.png",
  "1950_31c": "1950_31a-1950_31b-1950_31c.png",
  "1950_32a": "1950_32a-1950_32b-1950_32c.png",
  "1950_32b": "1950_32a-1950_32b-1950_32c.png",
  "1950_32c": "1950_32a-1950_32b-1950_32c.png",
  "1950_33a": "1950_33a-1950_33b-1950_33c.png",
  "1950_33b": "1950_33a-1950_33b-1950_33c.png",
  "1950_33c": "1950_33a-1950_33b-1950_33c.png",
  "1950_35a": "1950_35a.png",
  "1950_35b": "1950_35b.png",
  "1950_35c": "1950_35c.png",
  "1950_36": "1950_36.png",
  "1950_37": "1950_37.png",
  "1950_38": "1950_38.png",
  "1950_4": "1950_4.png",
  "1950_5": "1950_5.png",
  "1950_7": "1950_7.png",
  "1950_8": "1950_8.png",
  "1950_9": "1950_9.png",
  "1950_H": "1950_H.png",
  "1960_H": "1960_H.png",
  "1960_P10": "1960_P10.png",
  "1960_P11": "1960_P11.png",
  "1960_P12": "1960_P12.png",
  "1960_P13": "1960_P13.png",
  "1960_P14": "1960_P14.png",
  "1960_P15": "1960_P15.png",
  "1960_P16": "1960_P16-1960_P17.png",
  "1960_P17": "1960_P16-1960_P17.png",
  "1960_P18": "1960_P18-1960_P19.png",
  "1960_P19": "1960_P18-1960_P19.png",
  "1960_P2": "1960_P2.png",
  "1960_P20": "1960_P20.png",
  "1960_P21": "1960_P21.png",
  "1960_P22": "1960_P22-1960_P23.png",
  "1960_P23": "1960_P22-1960_P23.png",
  "1960_P24": "1960_P24.png",
  "1960_P25": "1960_P25.png",
  "1960_P26": "1960_P26.png",
  "1960_P27": "1960_P27.png",
  "1960_P27a": "1960_P27a.png",
  "1960_P27b": "1960_P27b.png",
  "1960_P27c": "1960_P27c.png",
  "1960_P27d": "1960_P27d.png",
  "1960_P27e": "1960_P27e.png",
  "1960_P28": "1960_P28-1960_P29.png",
  "1960_P29": "1960_P28-1960_P29.png",
  "1960_P3": "1960_P3.png",
  "1960_P30": "1960_P30-1960_P31.png",
  "1960_P31": "1960_P30-1960_P31.png",
  "1960_P32": "1960_P32.png",
  "1960_P33": "1960_P33.png",
  "1960_P34": "1960_P34.png",
  "1960_P35": "1960_P35.png",
  "1960_P4": "1960_P4.png",
  "1960_P5": "1960_P5.png",
  "1960_P6": "1960_P6.png",
  "1960_P7": "1960_P7.png",
  "1960_P8": "1960_P8.png",
  "1960_P9": "1960_P9.png",
  "1970_1": "1970_1.png",
  "1970_13a": "1970_13a-1970_13b.png",
  "1970_13b": "1970_13a-1970_13b.png",
  "1970_14": "1970_14.png",
  "1970_15": "1970_15.png",
  "1970_16a": "1970_16a-1970_16b.png",
  "1970_16b": "1970_16a-1970_16b.png",
  "1970_17": "1970_17.png",
  "1970_18": "1970_18.png",
  "1970_19a": "1970_19a-1970_19b.png",
  "1970_19b": "1970_19a-1970_19b.png",
  "1970_2": "1970_2.png",
  "1970_20": "1970_20.png",
  "1970_21": "1970_21.png",
  "1970_22": "1970_22.png",
  "1970_24a": "1970_24a-1970_24b-1970_24c.png",
  "1970_24b": "1970_24a-1970_24b-1970_24c.png",
  "1970_24c": "1970_24a-1970_24b-1970_24c.png",
  "1970_25": "1970_25.png",
  "1970_26a": "1970_26a-1970_26b.png",
  "1970_26b": "1970_26a-1970_26b.png",
  "1970_27a": "1970_27a-1970_27b.png",
  "1970_27b": "1970_27a-1970_27b.png",
  "1970_28a": "1970_28a-1970_28b-1970_28c.png",
  "1970_28b": "1970_28a-1970_28b-1970_28c.png",
  "1970_28c": "1970_28a-1970_28b-1970_28c.png",
  "1970_29a": "1970_29a-1970_29b.png",
  "1970_29b": "1970_29a-1970_29b.png",
  "1970_29c": "1970_29c.png",
  "1970_29d": "1970_29d.png",
  "1970_3": "1970_3.png",
  "1970_30": "1970_30.png",
  "1970_31a": "1970_31a-1970_31b.png",
  "1970_31b": "1970_31a-1970_31b.png",
  "1970_32": "1970_32.png",
  "1970_33a": "1970_33a-1970_33b-1970_33c.png",
  "1970_33b": "1970_33a-1970_33b-1970_33c.png",
  "1970_33c": "1970_33a-1970_33b-1970_33c.png",
  "1970_34a": "1970_34a-1970_34b-1970_34c.png",
  "1970_34b": "1970_34a-1970_34b-1970_34c.png",
  "1970_34c": "1970_34a-1970_34b-1970_34c.png",
  "1970_35": "1970_35.png",
  "1970_36": "1970_36.png",
  "1970_37a": "1970_37a-1970_37b-1970_37c.png",
  "1970_37b": "1970_37a-1970_37b-1970_37c.png",
  "1970_37c": "1970_37a-1970_37b-1970_37c.png",
  "1970_38a": "1970_38a-1970_38b-1970_38c.png",
  "1970_38b": "1970_38a-1970_38b-1970_38c.png",
  "1970_38c": "1970_38a-1970_38b-1970_38c.png",
  "1970_39a": "1970_39a-1970_39b.png",
  "1970_39b": "1970_39a-1970_39b.png",
  "1970_4": "1970_4.png",
  "1970_40a": "1970_40a-1970_40b-1970_40c.png",
  "1970_40b": "1970_40a-1970_40b-1970_40c.png",
  "1970_40c": "1970_40a-1970_40b-1970_40c.png",
  "1970_41a": "1970_41a-1970_41b-1970_41c.png",
  "1970_41b": "1970_41a-1970_41b-1970_41c.png",
  "1970_41c": "1970_41a-1970_41b-1970_41c.png",
  "1970_5": "1970_5-1970_6-1970_7.png",
  "1970_6": "1970_5-1970_6-1970_7.png",
  "1970_7": "1970_5-1970_6-1970_7.png",
  "1970_8": "1970_8.png",
  "1970_H": "1970_H.png",
  "1980_1": "1980_1.png",
  "1980_10": "1980_10.png",
  "1980_11": "1980_11.png",
  "1980_12a": "1980_12a-1980_12b.png",
  "1980_12b": "1980_12a-1980_12b.png",
  "1980_13a": "1980_13a-1980_13b-1980_13c.png",
  "1980_13b": "1980_13a-1980_13b-1980_13c.png",
  "1980_13c": "1980_13a-1980_13b-1980_13c.png",
  "1980_14": "1980_14.png",
  "1980_15a": "1980_15a-1980_15b.png",
  "1980_15b": "1980_15a-1980_15b.png",
  "1980_17a": "1980_17a-1980_17b-1980_17c.png",
  "1980_17b": "1980_17a-1980_17b-1980_17c.png",
  "1980_17c": "1980_17a-1980_17b-1980_17c.png",
  "1980_18a": "1980_18a-1980_18b.png",
  "1980_18b": "1980_18a-1980_18b.png",
  "1980_19a": "1980_19a-1980_19b-1980_19c.png",
  "1980_19b": "1980_19a-1980_19b-1980_19c.png",
  "1980_19c": "1980_19a-1980_19b-1980_19c.png",
  "1980_2": "1980_2.png",
  "1980_20": "1980_20.png",
  "1980_21a": "1980_21a-1980_21b-1980_21c.png",
  "1980_21b": "1980_21a-1980_21b-1980_21c.png",
  "1980_21c": "1980_21a-1980_21b-1980_21c.png",
  "1980_22a": "1980_22a-1980_22b.png",
  "1980_22b": "1980_22a-1980_22b.png",
  "1980_23": "1980_23.png",
  "1980_24a": "1980_24a-1980_24b.png",
  "1980_24b": "1980_24a-1980_24b.png",
  "1980_24c": "1980_24c-1980_24d.png",
  "1980_24d": "1980_24c-1980_24d.png",
  "1980_25": "1980_25.png",
  "1980_26a": "1980_26a-1980_26b.png",
  "1980_26b": "1980_26a-1980_26b.png",
  "1980_27": "1980_27.png",
  "1980_28a": "1980_28a-1980_28b-1980_28c.png",
  "1980_28b": "1980_28a-1980_28b-1980_28c.png",
  "1980_28c": "1980_28a-1980_28b-1980_28c.png",
  "1980_29a": "1980_29a-1980_29b.png",
  "1980_29b": "1980_29a-1980_29b.png",
  "1980_3": "1980_3.png",
  "1980_30": "1980_30.png",
  "1980_31a": "1980_31a-1980_31b-1980_31c-1980_31d.png",
  "1980_31b": "1980_31a-1980_31b-1980_31c-1980_31d.png",
  "1980_31c": "1980_31a-1980_31b-1980_31c-1980_31d.png",
  "1980_31d": "1980_31a-1980_31b-1980_31c-1980_31d.png",
  "1980_32a": "1980_32a-1980_32b.png",
  "1980_32b": "1980_32a-1980_32b.png",
  "1980_32c": "1980_32c-1980_32d-1980_32e.png",
  "1980_32d": "1980_32c-1980_32d-1980_32e.png",
  "1980_32e": "1980_32c-1980_32d-1980_32e.png",
  "1980_32f": "1980_32f-1980_32g.png",
  "1980_32g": "1980_32f-1980_32g.png",
  "1980_33": "1980_33.png",
  "1980_4": "1980_4.png",
  "1980_5a": "1980_5a.png",
  "1980_5b-5c": "1980_5b-5c.png",
  "1980_6": "1980_6.png",
  "1980_7": "1980_7.png",
  "1980_8": "1980_8.png",
  "1980_9": "1980_9.png",
  "1980_H": "1980_H.png",
  "1990_1": "1990_1.png",
  "1990_10": "1990_10.png",
  "1990_11": "1990_11.png",
  "1990_12": "1990_12.png",
  "1990_13": "1990_13.png",
  "1990_14a": "1990_14a-1990_14b.png",
  "1990_14b": "1990_14a-1990_14b.png",
  "1990_15a": "1990_15a-1990_15b-1990_15c.png",
  "1990_15b": "1990_15a-1990_15b-1990_15c.png",
  "1990_15c": "1990_15a-1990_15b-1990_15c.png",
  "1990_16": "1990_16.png",
  "1990_17a": "1990_17a-1990_17b-1990_17c.png",
  "1990_17b": "1990_17a-1990_17b-1990_17c.png",
  "1990_17c": "1990_17a-1990_17b-1990_17c.png",
  "1990_18a": "1990_18a-1990_18b.png",
  "1990_18b": "1990_18a-1990_18b.png",
  "1990_19a": "1990_19a-1990_19b.png",
  "1990_19b": "1990_19a-1990_19b.png",
  "1990_2": "1990_2.png",
  "1990_20": "1990_20.png",
  "1990_21a": "1990_21a-1990_21b.png",
  "1990_21b": "1990_21a-1990_21b.png",
  "1990_22": "1990_22.png",
  "1990_23a": "1990_23a-1990_23b.png",
  "1990_23b": "1990_23a-1990_23b.png",
  "1990_24a": "1990_24a-1990_24b.png",
  "1990_24b": "1990_24a-1990_24b.png",
  "1990_25": "1990_25.png",
  "1990_26a": "1990_26a-1990_26b.png",
  "1990_26b": "1990_26a-1990_26b.png",
  "1990_27": "1990_27.png",
  "1990_28a": "1990_28a-1990_28b-1990_28c.png",
  "1990_28b": "1990_28a-1990_28b-1990_28c.png",
  "1990_28c": "1990_28a-1990_28b-1990_28c.png",
  "1990_29a": "1990_29a-1990_29b.png",
  "1990_29b": "1990_29a-1990_29b.png",
  "1990_3": "1990_3.png",
  "1990_30": "1990_30.png",
  "1990_31a": "1990_31a-1990_31b-1990_31c.png",
  "1990_31b": "1990_31a-1990_31b-1990_31c.png",
  "1990_31c": "1990_31a-1990_31b-1990_31c.png",
  "1990_32a": "1990_32a-1990_32b.png",
  "1990_32b": "1990_32a-1990_32b.png",
  "1990_32c": "1990_32c-1990_32d-1990_32e.png",
  "1990_32d": "1990_32c-1990_32d-1990_32e.png",
  "1990_32e": "1990_32c-1990_32d-1990_32e.png",
  "1990_32f": "1990_32f-1990_32g-1990_32h.png",
  "1990_32g": "1990_32f-1990_32g-1990_32h.png",
  "1990_32h": "1990_32f-1990_32g-1990_32h.png",
  "1990_33": "1990_33.png",
  "1990_4": "1990_4.png",
  "1990_5a": "1990_5a-1990_5b.png",
  "1990_5b": "1990_5a-1990_5b.png",
  "1990_6": "1990_6.png",
  "1990_7": "1990_7.png",
  "1990_8": "1990_8.png",
  "1990_9": "1990_9.png",
  "1990_H": "1990_H.png",
  "2000_1": "2000_1.png",
  "2000_10": "2000_10.png",
  "2000_11a": "2000_11a-2000_11b-2000_11c.png",
  "2000_11b": "2000_11a-2000_11b-2000_11c.png",
  "2000_11c": "2000_11a-2000_11b-2000_11c.png",
  "2000_12": "2000_12.png",
  "2000_13": "2000_13.png",
  "2000_14": "2000_14.png",
  "2000_15a": "2000_15a.png",
  "2000_15b": "2000_15b.png",
  "2000_16a": "2000_16a-2000_16b.png",
  "2000_16b": "2000_16a-2000_16b.png",
  "2000_17a": "2000_17a-2000_17b-2000_17c-2000_17d.png",
  "2000_17b": "2000_17a-2000_17b-2000_17c-2000_17d.png",
  "2000_17c": "2000_17a-2000_17b-2000_17c-2000_17d.png",
  "2000_17d": "2000_17a-2000_17b-2000_17c-2000_17d.png",
  "2000_19a": "2000_19a-2000_19b-2000_19c.png",
  "2000_19b": "2000_19a-2000_19b-2000_19c.png",
  "2000_19c": "2000_19a-2000_19b-2000_19c.png",
  "2000_2": "2000_2.png",
  "2000_20a": "2000_20a-2000_20b-2000_20c.png",
  "2000_20b": "2000_20a-2000_20b-2000_20c.png",
  "2000_20c": "2000_20a-2000_20b-2000_20c.png",
  "2000_21": "2000_21.png",
  "2000_22": "2000_22.png",
  "2000_23a": "2000_23a.png",
  "2000_23b": "2000_23b.png",
  "2000_24a": "2000_24a-2000_24b.png",
  "2000_24b": "2000_24a-2000_24b.png",
  "2000_25a": "2000_25a-2000_25b-2000_25c-2000_25d-2000_25e.png",
  "2000_25b": "2000_25a-2000_25b-2000_25c-2000_25d-2000_25e.png",
  "2000_25c": "2000_25a-2000_25b-2000_25c-2000_25d-2000_25e.png",
  "2000_25d": "2000_25a-2000_25b-2000_25c-2000_25d-2000_25e.png",
  "2000_25e": "2000_25a-2000_25b-2000_25c-2000_25d-2000_25e.png",
  "2000_26": "2000_26.png",
  "2000_27a": "2000_27a.png",
  "2000_27b": "2000_27b-2000_27c.png",
  "2000_27c": "2000_27b-2000_27c.png",
  "2000_28a": "2000_28a-2000_28b.png",
  "2000_28b": "2000_28a-2000_28b.png",
  "2000_29": "2000_29.png",
  "2000_3": "2000_3.png",
  "2000_30a": "2000_30a-2000_30b-2000_30c.png",
  "2000_30b": "2000_30a-2000_30b-2000_30c.png",
  "2000_30c": "2000_30a-2000_30b-2000_30c.png",
  "2000_31a": "2000_31a-2000_31b.png",
  "2000_31b": "2000_31a-2000_31b.png",
  "2000_31c": "2000_31c-2000_31d-2000_31e.png",
  "2000_31d": "2000_31c-2000_31d-2000_31e.png",
  "2000_31e": "2000_31c-2000_31d-2000_31e.png",
  "2000_31f": "2000_31f-2000_31g-2000_31h.png",
  "2000_31g": "2000_31f-2000_31g-2000_31h.png",
  "2000_31h": "2000_31f-2000_31g-2000_31h.png",
  "2000_32": "2000_32.png",
  "2000_4": "2000_4.png",
  "2000_5": "2000_5.png",
  "2000_6": "2000_6.png",
  "2000_7": "2000_7.png",
  "2000_8a": "2000_8a-2000_8b.png",
  "2000_8b": "2000_8a-2000_8b.png",
  "2000_9": "2000_9.png",
  "2000_H": "2000_H.png",
  "2000_r1": "2000_r1.png",
  "2000_r2": "2000_r2.png",
  "2000_r4": "2000_r4.png",
  "2010_1": "2010_1.png",
  "2010_2": "2010_2.png",
  "2010_3": "2010_3.png",
  "2010_4": "2010_4.png",
  "2010_5": "2010_5.png",
  "2010_6": "2010_6.png",
  "2010_7": "2010_7.png",
  "2010_r3": "2010_r3.png",
  "2020_1": "2020_1.png",
  "2020_2": "2020_2.png",
  "2020_3": "2020_3.png",
  "2020_4": "2020_4.png",
  "2020_5": "2020_5.png",
  "2020_6": "2020_6.png",
  "2020_7": "2020_7.png",
  "2020_r3": "2020_r3.png"
};
},{}],"iJA9":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _imageFilesLookup = _interopRequireDefault(require("../assets/data/imageFilesLookup.json"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = {
  CATEGORIES: "Categories",
  UNIT: "Unit",
  ASKED_OF: "Asked of",
  ANSWER_TYPE: "Answer Type",
  AGE_RANGE: "Age range",
  UID: "UID",
  QUESTION: "Question",
  YEAR: "Year",
  OPTIONS: "Categorical options",
  START_YEAR: "startYear",
  END_YEAR: "endYear",
  EVENT: "event",
  MARGIN: 100,
  MOBILE_BREAKPT: 768,
  DEFAULT: "default",
  HOUSING: "housing",
  IMMIGRATION: "immigration",
  START_ACS: "2010_ACS",
  COLORS: ["#d50000", "#f57c00", "#8e24aa", "#ffea00", "#9c5a33", "#448aff", "#388e3c", "#f06292", "#9e9e9e", "#26c6da", "#ffb74d"],
  sortedCategories: ["Occupation", "Veteran status", "Immigration", "Education", "Family", "Identity", "[Multiple]", "Race", "Disability", "National origin", "Housing"],
  answerTypeLookup: {
    FT: "Text",
    BN: "Yes/No",
    CC: "Multiple Choice",
    FN: "Number",
    FD: "Date/Time",
    FM: "Dollar Amount"
  },
  unitReverseLookup: {
    Individual: "individual",
    "Sampled Individual": "individualS",
    "Reference Individual": "individual",
    Household: "household",
    "Sampled Household": "householdS",
    "Indiv. in sampled household": "householdSI"
  },
  years: [1790, 1800, 1810, 1820, 1830, 1840, 1850, 1860, 1870, 1880, 1890, 1900, 1910, 1920, 1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020],
  imageFilesLookup: _imageFilesLookup.default
};
exports.default = _default;
},{"../assets/data/imageFilesLookup.json":"flIy"}],"CHz1":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

function _default(a, b) {
  return a < b ? -1 : a > b ? 1 : a >= b ? 0 : NaN;
}
},{}],"TH2p":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _ascending = _interopRequireDefault(require("./ascending.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default(compare) {
  if (compare.length === 1) compare = ascendingComparator(compare);
  return {
    left: function (a, x, lo, hi) {
      if (lo == null) lo = 0;
      if (hi == null) hi = a.length;

      while (lo < hi) {
        var mid = lo + hi >>> 1;
        if (compare(a[mid], x) < 0) lo = mid + 1;else hi = mid;
      }

      return lo;
    },
    right: function (a, x, lo, hi) {
      if (lo == null) lo = 0;
      if (hi == null) hi = a.length;

      while (lo < hi) {
        var mid = lo + hi >>> 1;
        if (compare(a[mid], x) > 0) hi = mid;else lo = mid + 1;
      }

      return lo;
    }
  };
}

function ascendingComparator(f) {
  return function (d, x) {
    return (0, _ascending.default)(f(d), x);
  };
}
},{"./ascending.js":"CHz1"}],"Yob9":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.bisectLeft = exports.bisectRight = void 0;

var _ascending = _interopRequireDefault(require("./ascending.js"));

var _bisector = _interopRequireDefault(require("./bisector.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ascendingBisect = (0, _bisector.default)(_ascending.default);
var bisectRight = ascendingBisect.right;
exports.bisectRight = bisectRight;
var bisectLeft = ascendingBisect.left;
exports.bisectLeft = bisectLeft;
var _default = bisectRight;
exports.default = _default;
},{"./ascending.js":"CHz1","./bisector.js":"TH2p"}],"qen7":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = count;

function count(values, valueof) {
  let count = 0;

  if (valueof === undefined) {
    for (let value of values) {
      if (value != null && (value = +value) >= value) {
        ++count;
      }
    }
  } else {
    let index = -1;

    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null && (value = +value) >= value) {
        ++count;
      }
    }
  }

  return count;
}
},{}],"xaEI":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = cross;

function length(array) {
  return array.length | 0;
}

function empty(length) {
  return !(length > 0);
}

function arrayify(values) {
  return typeof values !== "object" || "length" in values ? values : Array.from(values);
}

function reducer(reduce) {
  return values => reduce(...values);
}

function cross(...values) {
  const reduce = typeof values[values.length - 1] === "function" && reducer(values.pop());
  values = values.map(arrayify);
  const lengths = values.map(length);
  const j = values.length - 1;
  const index = new Array(j + 1).fill(0);
  const product = [];
  if (j < 0 || lengths.some(empty)) return product;

  while (true) {
    product.push(index.map((j, i) => values[i][j]));
    let i = j;

    while (++index[i] === lengths[i]) {
      if (i === 0) return reduce ? product.map(reduce) : product;
      index[i--] = 0;
    }
  }
}
},{}],"LPRC":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = cumsum;

function cumsum(values, valueof) {
  var sum = 0,
      index = 0;
  return Float64Array.from(values, valueof === undefined ? v => sum += +v || 0 : v => sum += +valueof(v, index++, values) || 0);
}
},{}],"s7oJ":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

function _default(a, b) {
  return b < a ? -1 : b > a ? 1 : b >= a ? 0 : NaN;
}
},{}],"dVf8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = variance;

function variance(values, valueof) {
  let count = 0;
  let delta;
  let mean = 0;
  let sum = 0;

  if (valueof === undefined) {
    for (let value of values) {
      if (value != null && (value = +value) >= value) {
        delta = value - mean;
        mean += delta / ++count;
        sum += delta * (value - mean);
      }
    }
  } else {
    let index = -1;

    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null && (value = +value) >= value) {
        delta = value - mean;
        mean += delta / ++count;
        sum += delta * (value - mean);
      }
    }
  }

  if (count > 1) return sum / (count - 1);
}
},{}],"gdWJ":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = deviation;

var _variance = _interopRequireDefault(require("./variance.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function deviation(values, valueof) {
  const v = (0, _variance.default)(values, valueof);
  return v ? Math.sqrt(v) : v;
}
},{"./variance.js":"dVf8"}],"CLkD":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

function _default(values, valueof) {
  let min;
  let max;

  if (valueof === undefined) {
    for (const value of values) {
      if (value != null) {
        if (min === undefined) {
          if (value >= value) min = max = value;
        } else {
          if (min > value) min = value;
          if (max < value) max = value;
        }
      }
    }
  } else {
    let index = -1;

    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null) {
        if (min === undefined) {
          if (value >= value) min = max = value;
        } else {
          if (min > value) min = value;
          if (max < value) max = value;
        }
      }
    }
  }

  return [min, max];
}
},{}],"IRat":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

function _default(x) {
  return x;
}
},{}],"lUE8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = group;
exports.groups = groups;
exports.rollup = rollup;
exports.rollups = rollups;

var _identity = _interopRequireDefault(require("./identity.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function group(values, ...keys) {
  return nest(values, _identity.default, _identity.default, keys);
}

function groups(values, ...keys) {
  return nest(values, Array.from, _identity.default, keys);
}

function rollup(values, reduce, ...keys) {
  return nest(values, _identity.default, reduce, keys);
}

function rollups(values, reduce, ...keys) {
  return nest(values, Array.from, reduce, keys);
}

function nest(values, map, reduce, keys) {
  return function regroup(values, i) {
    if (i >= keys.length) return reduce(values);
    const groups = new Map();
    const keyof = keys[i++];
    let index = -1;

    for (const value of values) {
      const key = keyof(value, ++index, values);
      const group = groups.get(key);
      if (group) group.push(value);else groups.set(key, [value]);
    }

    for (const [key, values] of groups) {
      groups.set(key, regroup(values, i));
    }

    return map(groups);
  }(values, 0);
}
},{"./identity.js":"IRat"}],"gb1M":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.map = exports.slice = void 0;
var array = Array.prototype;
var slice = array.slice;
exports.slice = slice;
var map = array.map;
exports.map = map;
},{}],"OKWp":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

function _default(x) {
  return function () {
    return x;
  };
}
},{}],"p0JS":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

function _default(start, stop, step) {
  start = +start, stop = +stop, step = (n = arguments.length) < 2 ? (stop = start, start = 0, 1) : n < 3 ? 1 : +step;
  var i = -1,
      n = Math.max(0, Math.ceil((stop - start) / step)) | 0,
      range = new Array(n);

  while (++i < n) {
    range[i] = start + i * step;
  }

  return range;
}
},{}],"ZDeh":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;
exports.tickIncrement = tickIncrement;
exports.tickStep = tickStep;
var e10 = Math.sqrt(50),
    e5 = Math.sqrt(10),
    e2 = Math.sqrt(2);

function _default(start, stop, count) {
  var reverse,
      i = -1,
      n,
      ticks,
      step;
  stop = +stop, start = +start, count = +count;
  if (start === stop && count > 0) return [start];
  if (reverse = stop < start) n = start, start = stop, stop = n;
  if ((step = tickIncrement(start, stop, count)) === 0 || !isFinite(step)) return [];

  if (step > 0) {
    start = Math.ceil(start / step);
    stop = Math.floor(stop / step);
    ticks = new Array(n = Math.ceil(stop - start + 1));

    while (++i < n) ticks[i] = (start + i) * step;
  } else {
    start = Math.floor(start * step);
    stop = Math.ceil(stop * step);
    ticks = new Array(n = Math.ceil(start - stop + 1));

    while (++i < n) ticks[i] = (start - i) / step;
  }

  if (reverse) ticks.reverse();
  return ticks;
}

function tickIncrement(start, stop, count) {
  var step = (stop - start) / Math.max(0, count),
      power = Math.floor(Math.log(step) / Math.LN10),
      error = step / Math.pow(10, power);
  return power >= 0 ? (error >= e10 ? 10 : error >= e5 ? 5 : error >= e2 ? 2 : 1) * Math.pow(10, power) : -Math.pow(10, -power) / (error >= e10 ? 10 : error >= e5 ? 5 : error >= e2 ? 2 : 1);
}

function tickStep(start, stop, count) {
  var step0 = Math.abs(stop - start) / Math.max(0, count),
      step1 = Math.pow(10, Math.floor(Math.log(step0) / Math.LN10)),
      error = step0 / step1;
  if (error >= e10) step1 *= 10;else if (error >= e5) step1 *= 5;else if (error >= e2) step1 *= 2;
  return stop < start ? -step1 : step1;
}
},{}],"H59p":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _count = _interopRequireDefault(require("../count.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default(values) {
  return Math.ceil(Math.log((0, _count.default)(values)) / Math.LN2) + 1;
}
},{"../count.js":"qen7"}],"XtZq":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _array = require("./array.js");

var _bisect = _interopRequireDefault(require("./bisect.js"));

var _constant = _interopRequireDefault(require("./constant.js"));

var _extent = _interopRequireDefault(require("./extent.js"));

var _identity = _interopRequireDefault(require("./identity.js"));

var _range = _interopRequireDefault(require("./range.js"));

var _ticks = require("./ticks.js");

var _sturges = _interopRequireDefault(require("./threshold/sturges.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default() {
  var value = _identity.default,
      domain = _extent.default,
      threshold = _sturges.default;

  function histogram(data) {
    if (!Array.isArray(data)) data = Array.from(data);
    var i,
        n = data.length,
        x,
        values = new Array(n);

    for (i = 0; i < n; ++i) {
      values[i] = value(data[i], i, data);
    }

    var xz = domain(values),
        x0 = xz[0],
        x1 = xz[1],
        tz = threshold(values, x0, x1); // Convert number of thresholds into uniform thresholds.

    if (!Array.isArray(tz)) {
      tz = (0, _ticks.tickStep)(x0, x1, tz);
      tz = (0, _range.default)(Math.ceil(x0 / tz) * tz, x1, tz); // exclusive
    } // Remove any thresholds outside the domain.


    var m = tz.length;

    while (tz[0] <= x0) tz.shift(), --m;

    while (tz[m - 1] > x1) tz.pop(), --m;

    var bins = new Array(m + 1),
        bin; // Initialize bins.

    for (i = 0; i <= m; ++i) {
      bin = bins[i] = [];
      bin.x0 = i > 0 ? tz[i - 1] : x0;
      bin.x1 = i < m ? tz[i] : x1;
    } // Assign data to bins by value, ignoring any outside the domain.


    for (i = 0; i < n; ++i) {
      x = values[i];

      if (x0 <= x && x <= x1) {
        bins[(0, _bisect.default)(tz, x, 0, m)].push(data[i]);
      }
    }

    return bins;
  }

  histogram.value = function (_) {
    return arguments.length ? (value = typeof _ === "function" ? _ : (0, _constant.default)(_), histogram) : value;
  };

  histogram.domain = function (_) {
    return arguments.length ? (domain = typeof _ === "function" ? _ : (0, _constant.default)([_[0], _[1]]), histogram) : domain;
  };

  histogram.thresholds = function (_) {
    return arguments.length ? (threshold = typeof _ === "function" ? _ : Array.isArray(_) ? (0, _constant.default)(_array.slice.call(_)) : (0, _constant.default)(_), histogram) : threshold;
  };

  return histogram;
}
},{"./array.js":"gb1M","./bisect.js":"Yob9","./constant.js":"OKWp","./extent.js":"CLkD","./identity.js":"IRat","./range.js":"p0JS","./ticks.js":"ZDeh","./threshold/sturges.js":"H59p"}],"x9wj":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = max;

function max(values, valueof) {
  let max;

  if (valueof === undefined) {
    for (const value of values) {
      if (value != null && (max < value || max === undefined && value >= value)) {
        max = value;
      }
    }
  } else {
    let index = -1;

    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null && (max < value || max === undefined && value >= value)) {
        max = value;
      }
    }
  }

  return max;
}
},{}],"GKKy":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = min;

function min(values, valueof) {
  let min;

  if (valueof === undefined) {
    for (const value of values) {
      if (value != null && (min > value || min === undefined && value >= value)) {
        min = value;
      }
    }
  } else {
    let index = -1;

    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null && (min > value || min === undefined && value >= value)) {
        min = value;
      }
    }
  }

  return min;
}
},{}],"CLiU":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = quickselect;

var _ascending = _interopRequireDefault(require("./ascending.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Based on https://github.com/mourner/quickselect
// ISC license, Copyright 2018 Vladimir Agafonkin.
function quickselect(array, k, left = 0, right = array.length - 1, compare = _ascending.default) {
  while (right > left) {
    if (right - left > 600) {
      const n = right - left + 1;
      const m = k - left + 1;
      const z = Math.log(n);
      const s = 0.5 * Math.exp(2 * z / 3);
      const sd = 0.5 * Math.sqrt(z * s * (n - s) / n) * (m - n / 2 < 0 ? -1 : 1);
      const newLeft = Math.max(left, Math.floor(k - m * s / n + sd));
      const newRight = Math.min(right, Math.floor(k + (n - m) * s / n + sd));
      quickselect(array, k, newLeft, newRight, compare);
    }

    const t = array[k];
    let i = left;
    let j = right;
    swap(array, left, k);
    if (compare(array[right], t) > 0) swap(array, left, right);

    while (i < j) {
      swap(array, i, j), ++i, --j;

      while (compare(array[i], t) < 0) ++i;

      while (compare(array[j], t) > 0) --j;
    }

    if (compare(array[left], t) === 0) swap(array, left, j);else ++j, swap(array, j, right);
    if (j <= k) left = j + 1;
    if (k <= j) right = j - 1;
  }

  return array;
}

function swap(array, i, j) {
  const t = array[i];
  array[i] = array[j];
  array[j] = t;
}
},{"./ascending.js":"CHz1"}],"Mz1A":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;
exports.numbers = numbers;

function _default(x) {
  return x === null ? NaN : +x;
}

function* numbers(values, valueof) {
  if (valueof === undefined) {
    for (let value of values) {
      if (value != null && (value = +value) >= value) {
        yield value;
      }
    }
  } else {
    let index = -1;

    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null && (value = +value) >= value) {
        yield value;
      }
    }
  }
}
},{}],"GHmv":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = quantile;
exports.quantileSorted = quantileSorted;

var _max = _interopRequireDefault(require("./max.js"));

var _min = _interopRequireDefault(require("./min.js"));

var _quickselect = _interopRequireDefault(require("./quickselect.js"));

var _number = _interopRequireWildcard(require("./number.js"));

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; if (obj != null) { var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function quantile(values, p, valueof) {
  values = Float64Array.from((0, _number.numbers)(values, valueof));
  if (!(n = values.length)) return;
  if ((p = +p) <= 0 || n < 2) return (0, _min.default)(values);
  if (p >= 1) return (0, _max.default)(values);
  var n,
      i = (n - 1) * p,
      i0 = Math.floor(i),
      value0 = (0, _max.default)((0, _quickselect.default)(values, i0).subarray(0, i0 + 1)),
      value1 = (0, _min.default)(values.subarray(i0 + 1));
  return value0 + (value1 - value0) * (i - i0);
}

function quantileSorted(values, p, valueof = _number.default) {
  if (!(n = values.length)) return;
  if ((p = +p) <= 0 || n < 2) return +valueof(values[0], 0, values);
  if (p >= 1) return +valueof(values[n - 1], n - 1, values);
  var n,
      i = (n - 1) * p,
      i0 = Math.floor(i),
      value0 = +valueof(values[i0], i0, values),
      value1 = +valueof(values[i0 + 1], i0 + 1, values);
  return value0 + (value1 - value0) * (i - i0);
}
},{"./max.js":"x9wj","./min.js":"GKKy","./quickselect.js":"CLiU","./number.js":"Mz1A"}],"cBAY":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _count = _interopRequireDefault(require("../count.js"));

var _quantile = _interopRequireDefault(require("../quantile.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default(values, min, max) {
  return Math.ceil((max - min) / (2 * ((0, _quantile.default)(values, 0.75) - (0, _quantile.default)(values, 0.25)) * Math.pow((0, _count.default)(values), -1 / 3)));
}
},{"../count.js":"qen7","../quantile.js":"GHmv"}],"lvim":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _count = _interopRequireDefault(require("../count.js"));

var _deviation = _interopRequireDefault(require("../deviation.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default(values, min, max) {
  return Math.ceil((max - min) / (3.5 * (0, _deviation.default)(values) * Math.pow((0, _count.default)(values), -1 / 3)));
}
},{"../count.js":"qen7","../deviation.js":"gdWJ"}],"qG2o":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = maxIndex;

function maxIndex(values, valueof) {
  let max;
  let maxIndex = -1;
  let index = -1;

  if (valueof === undefined) {
    for (const value of values) {
      ++index;

      if (value != null && (max < value || max === undefined && value >= value)) {
        max = value, maxIndex = index;
      }
    }
  } else {
    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null && (max < value || max === undefined && value >= value)) {
        max = value, maxIndex = index;
      }
    }
  }

  return maxIndex;
}
},{}],"cGYI":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = mean;

function mean(values, valueof) {
  let count = 0;
  let sum = 0;

  if (valueof === undefined) {
    for (let value of values) {
      if (value != null && (value = +value) >= value) {
        ++count, sum += value;
      }
    }
  } else {
    let index = -1;

    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null && (value = +value) >= value) {
        ++count, sum += value;
      }
    }
  }

  if (count) return sum / count;
}
},{}],"FfrF":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _quantile = _interopRequireDefault(require("./quantile.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default(values, valueof) {
  return (0, _quantile.default)(values, 0.5, valueof);
}
},{"./quantile.js":"GHmv"}],"EzuM":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = merge;

function* flatten(arrays) {
  for (const array of arrays) {
    yield* array;
  }
}

function merge(arrays) {
  return Array.from(flatten(arrays));
}
},{}],"Ym5e":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = minIndex;

function minIndex(values, valueof) {
  let min;
  let minIndex = -1;
  let index = -1;

  if (valueof === undefined) {
    for (const value of values) {
      ++index;

      if (value != null && (min > value || min === undefined && value >= value)) {
        min = value, minIndex = index;
      }
    }
  } else {
    for (let value of values) {
      if ((value = valueof(value, ++index, values)) != null && (min > value || min === undefined && value >= value)) {
        min = value, minIndex = index;
      }
    }
  }

  return minIndex;
}
},{}],"PuGY":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = pairs;
exports.pair = pair;

function pairs(values, pairof = pair) {
  const pairs = [];
  let previous;
  let first = false;

  for (const value of values) {
    if (first) pairs.push(pairof(previous, value));
    previous = value;
    first = true;
  }

  return pairs;
}

function pair(a, b) {
  return [a, b];
}
},{}],"XFTn":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

function _default(source, keys) {
  return Array.from(keys, key => source[key]);
}
},{}],"IxQK":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = least;

var _ascending = _interopRequireDefault(require("./ascending.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function least(values, compare = _ascending.default) {
  let min;
  let defined = false;

  if (compare.length === 1) {
    let minValue;

    for (const element of values) {
      const value = compare(element);

      if (defined ? (0, _ascending.default)(value, minValue) < 0 : (0, _ascending.default)(value, value) === 0) {
        min = element;
        minValue = value;
        defined = true;
      }
    }
  } else {
    for (const value of values) {
      if (defined ? compare(value, min) < 0 : compare(value, value) === 0) {
        min = value;
        defined = true;
      }
    }
  }

  return min;
}
},{"./ascending.js":"CHz1"}],"upcM":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = leastIndex;

var _ascending = _interopRequireDefault(require("./ascending.js"));

var _minIndex = _interopRequireDefault(require("./minIndex.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function leastIndex(values, compare = _ascending.default) {
  if (compare.length === 1) return (0, _minIndex.default)(values, compare);
  let minValue;
  let min = -1;
  let index = -1;

  for (const value of values) {
    ++index;

    if (min < 0 ? compare(value, value) === 0 : compare(value, minValue) < 0) {
      minValue = value;
      min = index;
    }
  }

  return min;
}
},{"./ascending.js":"CHz1","./minIndex.js":"Ym5e"}],"mwkB":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = greatest;

var _ascending = _interopRequireDefault(require("./ascending.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function greatest(values, compare = _ascending.default) {
  let max;
  let defined = false;

  if (compare.length === 1) {
    let maxValue;

    for (const element of values) {
      const value = compare(element);

      if (defined ? (0, _ascending.default)(value, maxValue) > 0 : (0, _ascending.default)(value, value) === 0) {
        max = element;
        maxValue = value;
        defined = true;
      }
    }
  } else {
    for (const value of values) {
      if (defined ? compare(value, max) > 0 : compare(value, value) === 0) {
        max = value;
        defined = true;
      }
    }
  }

  return max;
}
},{"./ascending.js":"CHz1"}],"hCzr":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = greatestIndex;

var _ascending = _interopRequireDefault(require("./ascending.js"));

var _maxIndex = _interopRequireDefault(require("./maxIndex.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function greatestIndex(values, compare = _ascending.default) {
  if (compare.length === 1) return (0, _maxIndex.default)(values, compare);
  let maxValue;
  let max = -1;
  let index = -1;

  for (const value of values) {
    ++index;

    if (max < 0 ? compare(value, value) === 0 : compare(value, maxValue) > 0) {
      maxValue = value;
      max = index;
    }
  }

  return max;
}
},{"./ascending.js":"CHz1","./maxIndex.js":"qG2o"}],"H5no":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = scan;

var _leastIndex = _interopRequireDefault(require("./leastIndex.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function scan(values, compare) {
  const index = (0, _leastIndex.default)(values, compare);
  return index < 0 ? undefined : index;
}
},{"./leastIndex.js":"upcM"}],"q8CL":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = shuffle;

function shuffle(array, i0 = 0, i1 = array.length) {
  var m = i1 - (i0 = +i0),
      t,
      i;

  while (m) {
    i = Math.random() * m-- | 0;
    t = array[m + i0];
    array[m + i0] = array[i + i0];
    array[i + i0] = t;
  }

  return array;
}
},{}],"tfh5":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = sum;

function sum(values, valueof) {
  let sum = 0;

  if (valueof === undefined) {
    for (let value of values) {
      if (value = +value) {
        sum += value;
      }
    }
  } else {
    let index = -1;

    for (let value of values) {
      if (value = +valueof(value, ++index, values)) {
        sum += value;
      }
    }
  }

  return sum;
}
},{}],"ovym":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _min = _interopRequireDefault(require("./min.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default(matrix) {
  if (!(n = matrix.length)) return [];

  for (var i = -1, m = (0, _min.default)(matrix, length), transpose = new Array(m); ++i < m;) {
    for (var j = -1, n, row = transpose[i] = new Array(n); ++j < n;) {
      row[j] = matrix[j][i];
    }
  }

  return transpose;
}

function length(d) {
  return d.length;
}
},{"./min.js":"GKKy"}],"DYHk":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _transpose = _interopRequireDefault(require("./transpose.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _default() {
  return (0, _transpose.default)(arguments);
}
},{"./transpose.js":"ovym"}],"Rpnd":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "bisect", {
  enumerable: true,
  get: function () {
    return _bisect.default;
  }
});
Object.defineProperty(exports, "bisectRight", {
  enumerable: true,
  get: function () {
    return _bisect.bisectRight;
  }
});
Object.defineProperty(exports, "bisectLeft", {
  enumerable: true,
  get: function () {
    return _bisect.bisectLeft;
  }
});
Object.defineProperty(exports, "ascending", {
  enumerable: true,
  get: function () {
    return _ascending.default;
  }
});
Object.defineProperty(exports, "bisector", {
  enumerable: true,
  get: function () {
    return _bisector.default;
  }
});
Object.defineProperty(exports, "count", {
  enumerable: true,
  get: function () {
    return _count.default;
  }
});
Object.defineProperty(exports, "cross", {
  enumerable: true,
  get: function () {
    return _cross.default;
  }
});
Object.defineProperty(exports, "cumsum", {
  enumerable: true,
  get: function () {
    return _cumsum.default;
  }
});
Object.defineProperty(exports, "descending", {
  enumerable: true,
  get: function () {
    return _descending.default;
  }
});
Object.defineProperty(exports, "deviation", {
  enumerable: true,
  get: function () {
    return _deviation.default;
  }
});
Object.defineProperty(exports, "extent", {
  enumerable: true,
  get: function () {
    return _extent.default;
  }
});
Object.defineProperty(exports, "group", {
  enumerable: true,
  get: function () {
    return _group.default;
  }
});
Object.defineProperty(exports, "groups", {
  enumerable: true,
  get: function () {
    return _group.groups;
  }
});
Object.defineProperty(exports, "rollup", {
  enumerable: true,
  get: function () {
    return _group.rollup;
  }
});
Object.defineProperty(exports, "rollups", {
  enumerable: true,
  get: function () {
    return _group.rollups;
  }
});
Object.defineProperty(exports, "bin", {
  enumerable: true,
  get: function () {
    return _bin.default;
  }
});
Object.defineProperty(exports, "histogram", {
  enumerable: true,
  get: function () {
    return _bin.default;
  }
});
Object.defineProperty(exports, "thresholdFreedmanDiaconis", {
  enumerable: true,
  get: function () {
    return _freedmanDiaconis.default;
  }
});
Object.defineProperty(exports, "thresholdScott", {
  enumerable: true,
  get: function () {
    return _scott.default;
  }
});
Object.defineProperty(exports, "thresholdSturges", {
  enumerable: true,
  get: function () {
    return _sturges.default;
  }
});
Object.defineProperty(exports, "max", {
  enumerable: true,
  get: function () {
    return _max.default;
  }
});
Object.defineProperty(exports, "maxIndex", {
  enumerable: true,
  get: function () {
    return _maxIndex.default;
  }
});
Object.defineProperty(exports, "mean", {
  enumerable: true,
  get: function () {
    return _mean.default;
  }
});
Object.defineProperty(exports, "median", {
  enumerable: true,
  get: function () {
    return _median.default;
  }
});
Object.defineProperty(exports, "merge", {
  enumerable: true,
  get: function () {
    return _merge.default;
  }
});
Object.defineProperty(exports, "min", {
  enumerable: true,
  get: function () {
    return _min.default;
  }
});
Object.defineProperty(exports, "minIndex", {
  enumerable: true,
  get: function () {
    return _minIndex.default;
  }
});
Object.defineProperty(exports, "pairs", {
  enumerable: true,
  get: function () {
    return _pairs.default;
  }
});
Object.defineProperty(exports, "permute", {
  enumerable: true,
  get: function () {
    return _permute.default;
  }
});
Object.defineProperty(exports, "quantile", {
  enumerable: true,
  get: function () {
    return _quantile.default;
  }
});
Object.defineProperty(exports, "quantileSorted", {
  enumerable: true,
  get: function () {
    return _quantile.quantileSorted;
  }
});
Object.defineProperty(exports, "quickselect", {
  enumerable: true,
  get: function () {
    return _quickselect.default;
  }
});
Object.defineProperty(exports, "range", {
  enumerable: true,
  get: function () {
    return _range.default;
  }
});
Object.defineProperty(exports, "least", {
  enumerable: true,
  get: function () {
    return _least.default;
  }
});
Object.defineProperty(exports, "leastIndex", {
  enumerable: true,
  get: function () {
    return _leastIndex.default;
  }
});
Object.defineProperty(exports, "greatest", {
  enumerable: true,
  get: function () {
    return _greatest.default;
  }
});
Object.defineProperty(exports, "greatestIndex", {
  enumerable: true,
  get: function () {
    return _greatestIndex.default;
  }
});
Object.defineProperty(exports, "scan", {
  enumerable: true,
  get: function () {
    return _scan.default;
  }
});
Object.defineProperty(exports, "shuffle", {
  enumerable: true,
  get: function () {
    return _shuffle.default;
  }
});
Object.defineProperty(exports, "sum", {
  enumerable: true,
  get: function () {
    return _sum.default;
  }
});
Object.defineProperty(exports, "ticks", {
  enumerable: true,
  get: function () {
    return _ticks.default;
  }
});
Object.defineProperty(exports, "tickIncrement", {
  enumerable: true,
  get: function () {
    return _ticks.tickIncrement;
  }
});
Object.defineProperty(exports, "tickStep", {
  enumerable: true,
  get: function () {
    return _ticks.tickStep;
  }
});
Object.defineProperty(exports, "transpose", {
  enumerable: true,
  get: function () {
    return _transpose.default;
  }
});
Object.defineProperty(exports, "variance", {
  enumerable: true,
  get: function () {
    return _variance.default;
  }
});
Object.defineProperty(exports, "zip", {
  enumerable: true,
  get: function () {
    return _zip.default;
  }
});

var _bisect = _interopRequireWildcard(require("./bisect.js"));

var _ascending = _interopRequireDefault(require("./ascending.js"));

var _bisector = _interopRequireDefault(require("./bisector.js"));

var _count = _interopRequireDefault(require("./count.js"));

var _cross = _interopRequireDefault(require("./cross.js"));

var _cumsum = _interopRequireDefault(require("./cumsum.js"));

var _descending = _interopRequireDefault(require("./descending.js"));

var _deviation = _interopRequireDefault(require("./deviation.js"));

var _extent = _interopRequireDefault(require("./extent.js"));

var _group = _interopRequireWildcard(require("./group.js"));

var _bin = _interopRequireDefault(require("./bin.js"));

var _freedmanDiaconis = _interopRequireDefault(require("./threshold/freedmanDiaconis.js"));

var _scott = _interopRequireDefault(require("./threshold/scott.js"));

var _sturges = _interopRequireDefault(require("./threshold/sturges.js"));

var _max = _interopRequireDefault(require("./max.js"));

var _maxIndex = _interopRequireDefault(require("./maxIndex.js"));

var _mean = _interopRequireDefault(require("./mean.js"));

var _median = _interopRequireDefault(require("./median.js"));

var _merge = _interopRequireDefault(require("./merge.js"));

var _min = _interopRequireDefault(require("./min.js"));

var _minIndex = _interopRequireDefault(require("./minIndex.js"));

var _pairs = _interopRequireDefault(require("./pairs.js"));

var _permute = _interopRequireDefault(require("./permute.js"));

var _quantile = _interopRequireWildcard(require("./quantile.js"));

var _quickselect = _interopRequireDefault(require("./quickselect.js"));

var _range = _interopRequireDefault(require("./range.js"));

var _least = _interopRequireDefault(require("./least.js"));

var _leastIndex = _interopRequireDefault(require("./leastIndex.js"));

var _greatest = _interopRequireDefault(require("./greatest.js"));

var _greatestIndex = _interopRequireDefault(require("./greatestIndex.js"));

var _scan = _interopRequireDefault(require("./scan.js"));

var _shuffle = _interopRequireDefault(require("./shuffle.js"));

var _sum = _interopRequireDefault(require("./sum.js"));

var _ticks = _interopRequireWildcard(require("./ticks.js"));

var _transpose = _interopRequireDefault(require("./transpose.js"));

var _variance = _interopRequireDefault(require("./variance.js"));

var _zip = _interopRequireDefault(require("./zip.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; if (obj != null) { var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
},{"./bisect.js":"Yob9","./ascending.js":"CHz1","./bisector.js":"TH2p","./count.js":"qen7","./cross.js":"xaEI","./cumsum.js":"LPRC","./descending.js":"s7oJ","./deviation.js":"gdWJ","./extent.js":"CLkD","./group.js":"lUE8","./bin.js":"XtZq","./threshold/freedmanDiaconis.js":"cBAY","./threshold/scott.js":"lvim","./threshold/sturges.js":"H59p","./max.js":"x9wj","./maxIndex.js":"qG2o","./mean.js":"cGYI","./median.js":"FfrF","./merge.js":"EzuM","./min.js":"GKKy","./minIndex.js":"Ym5e","./pairs.js":"PuGY","./permute.js":"XFTn","./quantile.js":"GHmv","./quickselect.js":"CLiU","./range.js":"p0JS","./least.js":"IxQK","./leastIndex.js":"upcM","./greatest.js":"mwkB","./greatestIndex.js":"hCzr","./scan.js":"H5no","./shuffle.js":"q8CL","./sum.js":"tfh5","./ticks.js":"ZDeh","./transpose.js":"ovym","./variance.js":"dVf8","./zip.js":"DYHk"}],"GHP6":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defaultMemoize = defaultMemoize;
exports.createSelectorCreator = createSelectorCreator;
exports.createStructuredSelector = createStructuredSelector;
exports.createSelector = void 0;

function defaultEqualityCheck(a, b) {
  return a === b;
}

function areArgumentsShallowlyEqual(equalityCheck, prev, next) {
  if (prev === null || next === null || prev.length !== next.length) {
    return false;
  } // Do this in a for loop (and not a `forEach` or an `every`) so we can determine equality as fast as possible.


  var length = prev.length;

  for (var i = 0; i < length; i++) {
    if (!equalityCheck(prev[i], next[i])) {
      return false;
    }
  }

  return true;
}

function defaultMemoize(func) {
  var equalityCheck = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultEqualityCheck;
  var lastArgs = null;
  var lastResult = null; // we reference arguments instead of spreading them for performance reasons

  return function () {
    if (!areArgumentsShallowlyEqual(equalityCheck, lastArgs, arguments)) {
      // apply arguments instead of spreading for performance.
      lastResult = func.apply(null, arguments);
    }

    lastArgs = arguments;
    return lastResult;
  };
}

function getDependencies(funcs) {
  var dependencies = Array.isArray(funcs[0]) ? funcs[0] : funcs;

  if (!dependencies.every(function (dep) {
    return typeof dep === 'function';
  })) {
    var dependencyTypes = dependencies.map(function (dep) {
      return typeof dep;
    }).join(', ');
    throw new Error('Selector creators expect all input-selectors to be functions, ' + ('instead received the following types: [' + dependencyTypes + ']'));
  }

  return dependencies;
}

function createSelectorCreator(memoize) {
  for (var _len = arguments.length, memoizeOptions = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    memoizeOptions[_key - 1] = arguments[_key];
  }

  return function () {
    for (var _len2 = arguments.length, funcs = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      funcs[_key2] = arguments[_key2];
    }

    var recomputations = 0;
    var resultFunc = funcs.pop();
    var dependencies = getDependencies(funcs);
    var memoizedResultFunc = memoize.apply(undefined, [function () {
      recomputations++; // apply arguments instead of spreading for performance.

      return resultFunc.apply(null, arguments);
    }].concat(memoizeOptions)); // If a selector is called with the exact same arguments we don't need to traverse our dependencies again.

    var selector = memoize(function () {
      var params = [];
      var length = dependencies.length;

      for (var i = 0; i < length; i++) {
        // apply arguments instead of spreading and mutate a local list of params for performance.
        params.push(dependencies[i].apply(null, arguments));
      } // apply arguments instead of spreading for performance.


      return memoizedResultFunc.apply(null, params);
    });
    selector.resultFunc = resultFunc;
    selector.dependencies = dependencies;

    selector.recomputations = function () {
      return recomputations;
    };

    selector.resetRecomputations = function () {
      return recomputations = 0;
    };

    return selector;
  };
}

var createSelector = createSelectorCreator(defaultMemoize);
exports.createSelector = createSelector;

function createStructuredSelector(selectors) {
  var selectorCreator = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : createSelector;

  if (typeof selectors !== 'object') {
    throw new Error('createStructuredSelector expects first argument to be an object ' + ('where each property is a selector, instead received a ' + typeof selectors));
  }

  var objectKeys = Object.keys(selectors);
  return selectorCreator(objectKeys.map(function (key) {
    return selectors[key];
  }), function () {
    for (var _len3 = arguments.length, values = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      values[_key3] = arguments[_key3];
    }

    return values.reduce(function (composition, value, index) {
      composition[objectKeys[index]] = value;
      return composition;
    }, {});
  });
}
},{}],"WULq":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var frac = function frac(a, b, f) {
  return a + f * (b - a);
};

var bezier = function bezier(sourceX, sourceY, targetX, targetY, hasBump, svgWidth) {
  var acs = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : false;

  if (hasBump) {
    var bump = (sourceX + targetX) / 2 > svgWidth / 2 ? svgWidth - 1 : 1;
    return "M".concat(sourceX, ",").concat(sourceY, "\n    C").concat(sourceX, ",").concat(frac(sourceY, targetY, 0.25), "\n    ").concat(bump, ",").concat(frac(sourceY, targetY, 0.25), "\n    ").concat(bump, ",").concat(frac(sourceY, targetY, 0.5), "\n    C").concat(bump, ",").concat(frac(sourceY, targetY, 0.75), "\n    ").concat(targetX, ",").concat(frac(sourceY, targetY, 0.75), "\n    ").concat(targetX, ",").concat(targetY);
  }

  if (acs) {
    return "M".concat(sourceX, ",").concat(sourceY, "\n            C").concat(sourceX, ",").concat(frac(sourceY, targetY, 0.75), "\n            ").concat(frac(sourceX, targetX, 0.75), ",").concat(targetY, "\n            ").concat(targetX, ",").concat(targetY);
  }

  return "M".concat(sourceX, ",").concat(sourceY, "\n  C").concat(sourceX, ",").concat(frac(sourceY, targetY, 0.5), "\n  ").concat(targetX, ",").concat(frac(sourceY, targetY, 0.5), "\n  ").concat(targetX, ",").concat(targetY);
};

var _default = bezier;
exports.default = _default;
},{}],"T3Gr":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.legendDataSelector = exports.linksSelector = exports.nodesSelector = exports.currentStoryStepYearLookupSelector = exports.xScaleSelector = exports.maxYearsSelector = exports.qsByYearLookupSelector = exports.interimDataQuestionsSelector = exports.useCurrentYearFilterSelector = exports.isMobileSelector = exports.currentYearInViewSelector = exports.yScaleSelector = exports.svgWidthSelector = exports.appHeightSelector = exports.currentStorySelector = exports.filtersSelector = exports.dataLinksSelector = exports.dataQuestionsSelector = void 0;

var _d3Array = require("d3-array");

var _reselect = require("reselect");

var _makeSvgPath = _interopRequireDefault(require("./utils/make-svg-path"));

var _constants = _interopRequireDefault(require("./constants"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _readOnlyError(name) { throw new Error("\"" + name + "\" is read-only"); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var YEAR = _constants.default.YEAR,
    UID = _constants.default.UID,
    CATEGORIES = _constants.default.CATEGORIES,
    START_ACS = _constants.default.START_ACS;

var dataQuestionsSelector = function dataQuestionsSelector(state) {
  return state.dataQuestions;
};

exports.dataQuestionsSelector = dataQuestionsSelector;

var dataLinksSelector = function dataLinksSelector(state) {
  return state.dataLinks;
};

exports.dataLinksSelector = dataLinksSelector;

var filtersSelector = function filtersSelector(state) {
  return state.filters;
};

exports.filtersSelector = filtersSelector;

var currentStorySelector = function currentStorySelector(state) {
  return state.storyMenu.find(function (d) {
    return d.key === state.currentStoryKey;
  });
};

exports.currentStorySelector = currentStorySelector;

var appHeightSelector = function appHeightSelector(state) {
  return state.appHeight;
};

exports.appHeightSelector = appHeightSelector;

var svgWidthSelector = function svgWidthSelector(state, props) {
  return props.svgWidth;
};

exports.svgWidthSelector = svgWidthSelector;

var yScaleSelector = function yScaleSelector(state, props) {
  return props.yScale;
};

exports.yScaleSelector = yScaleSelector;

var currentYearInViewSelector = function currentYearInViewSelector(state) {
  return state.currentYearInView;
};

exports.currentYearInViewSelector = currentYearInViewSelector;

var isMobileSelector = function isMobileSelector(state) {
  return state.isMobile;
};

exports.isMobileSelector = isMobileSelector;

var useCurrentYearFilterSelector = function useCurrentYearFilterSelector(state, props) {
  return props.useCurrentYearFilter;
};

exports.useCurrentYearFilterSelector = useCurrentYearFilterSelector;
var interimDataQuestionsSelector = (0, _reselect.createSelector)(dataQuestionsSelector, function (questions) {
  var interimDataQuestions = questions.slice(); // only works if dataQuestions is sorted by Year

  var indexByYear = 0;
  var year = questions[0][YEAR];
  interimDataQuestions.forEach(function (e) {
    if (e[UID] === START_ACS) {
      return;
    }

    if (e[YEAR] === year) {
      e.indexByYear = indexByYear;
    } else {
      e.indexByYear = indexByYear = 0;
      year = e[YEAR];
    }

    indexByYear++;
  });
  return interimDataQuestions;
});
exports.interimDataQuestionsSelector = interimDataQuestionsSelector;
var qsByYearLookupSelector = (0, _reselect.createSelector)(interimDataQuestionsSelector, function (questions) {
  return (0, _d3Array.rollup)(questions, function (values) {
    return values.length;
  }, function (d) {
    return d[YEAR];
  });
});
exports.qsByYearLookupSelector = qsByYearLookupSelector;
var maxYearsSelector = (0, _reselect.createSelector)(interimDataQuestionsSelector, function (questions) {
  return (0, _d3Array.max)(qsByYearLookupSelector(questions), function (d) {
    return d[1];
  });
}); // define xScale after indexByYear has been assigned

exports.maxYearsSelector = maxYearsSelector;
var xScaleSelector = (0, _reselect.createSelector)(svgWidthSelector, qsByYearLookupSelector, isMobileSelector, function (svgWidth, qsByYearLookup, isMobile) {
  var m1 = isMobile ? 0.05 : 0.15;
  var m2 = isMobile ? 0.9 : 0.8;
  return function (d) {
    return m1 * svgWidth + m2 * svgWidth * ((1 + d.indexByYear) / (1 + qsByYearLookup.get(d[YEAR])));
  };
});
exports.xScaleSelector = xScaleSelector;
var currentStoryStepYearLookupSelector = (0, _reselect.createSelector)(currentStorySelector, function (currentStory) {
  return (0, _d3Array.rollup)(currentStory.steps, function (d) {
    return d[0];
  }, function (d) {
    return d.year;
  });
}); // position questions that are in filter

exports.currentStoryStepYearLookupSelector = currentStoryStepYearLookupSelector;
var nodesSelector = (0, _reselect.createSelector)(interimDataQuestionsSelector, qsByYearLookupSelector, svgWidthSelector, xScaleSelector, yScaleSelector, filtersSelector, currentYearInViewSelector, useCurrentYearFilterSelector, function (questions, qsByYearLookup, svgWidth, xScale, yScale, filters, currentYearInView, useCurrentYearFilter) {
  return new Map(questions // if useCurrentYearFilter flag is true,
  // stay one decade ahead and three decades behind
  .filter(function (d) {
    return !useCurrentYearFilter || d[YEAR] <= currentYearInView + 10 && d[YEAR] >= currentYearInView - 30;
  }).map(function (d) {
    var inFilter = filters.reduce(function (acc, f) {
      return acc && (d[f.key] === "" || f.selectedValues.indexOf(d[f.key]) > -1);
    }, true);
    var x, y, r;

    if (d[UID] === START_ACS) {
      x = 0.95 * svgWidth;
      y = yScale(d[YEAR] - 3);
      r = 10;
    } else if (d[UID].slice(-2) === "_H") {
      x = 0.95 * svgWidth;
      y = yScale(d[YEAR]);
      r = 10;
    } else {
      x = xScale(d);
      y = yScale(d[YEAR]);
      r = Math.min(125, 180 / qsByYearLookup.get(d[YEAR]));
    }

    return [d[UID], _objectSpread({}, d, {
      x: x,
      y: y,
      r: r,
      inFilter: inFilter
    })];
  }));
});
exports.nodesSelector = nodesSelector;
var linksSelector = (0, _reselect.createSelector)(dataLinksSelector, nodesSelector, svgWidthSelector, function (links, nodes, svgWidth) {
  return links.filter(function (d) {
    return nodes.has(d.Source) && nodes.has(d.Target);
  }).map(function (d) {
    // use Category from source node instead of Links file
    var _nodes$get = nodes.get(d.Source),
        sourceX = _nodes$get.x,
        sourceY = _nodes$get.y,
        Category = _nodes$get[CATEGORIES],
        indexByYear = _nodes$get.indexByYear,
        sourceInFilter = _nodes$get.inFilter;

    var _nodes$get2 = nodes.get(d.Target),
        targetX = _nodes$get2.x,
        targetY = _nodes$get2.y,
        targetInFilter = _nodes$get2.inFilter;

    if (Category.indexOf(", ") !== -1) {
      Category = (_readOnlyError("Category"), "[Multiple]");
    }

    if (Category.indexOf(" - ") !== -1) {
      Category = (_readOnlyError("Category"), Category.split(" - ")[0]);
    }

    var svgPath = (0, _makeSvgPath.default)(sourceX, sourceY, targetX, targetY, +d.Target.slice(0, 4) - +d.Source.slice(0, 4) > 10, svgWidth, d.Target === START_ACS);
    return _objectSpread({}, d, {
      sourceX: sourceX,
      sourceY: sourceY,
      targetX: targetX,
      targetY: targetY,
      Category: Category,
      svgPath: svgPath,
      indexByYear: indexByYear,
      inFilter: sourceInFilter || targetInFilter
    });
  });
});
exports.linksSelector = linksSelector;
var legendDataSelector = (0, _reselect.createSelector)(dataQuestionsSelector, function (questions) {
  return (0, _d3Array.rollup)(questions, function (values) {
    return values.length;
  }, function (d) {
    return +d[YEAR];
  }, function (d) {
    return d[CATEGORIES];
  });
});
exports.legendDataSelector = legendDataSelector;
},{"d3-array":"Rpnd","reselect":"GHP6","./utils/make-svg-path":"WULq","./constants":"iJA9"}],"UNIr":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function immutableAddRemove(arr, elem) {
  var acc = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function (d) {
    return d;
  };
  var index = arr.findIndex(function (data) {
    return acc(data) === acc(elem);
  });
  return ~index ? [].concat(_toConsumableArray(arr.slice(0, index)), _toConsumableArray(arr.slice(index + 1))) : [].concat(_toConsumableArray(arr), [elem]);
}

var _default = immutableAddRemove;
exports.default = _default;
},{}],"GUzP":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _constants = _interopRequireDefault(require("../constants"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var UID = _constants.default.UID;

var areListsEqual = function areListsEqual(a, b) {
  return a.length === b.length && a.reduce(function (t, v) {
    return t && b.includes(v);
  }, true);
};

var areFiltersEqual = function areFiltersEqual(a, b) {
  return a.reduce(function (t, leftFilter) {
    var rightFilter = b.find(function (d) {
      return d.key === leftFilter.key;
    });
    if (!rightFilter) return false;
    return t && areListsEqual(leftFilter.selectedValues, rightFilter.selectedValues);
  }, true);
};

var areTooltipsEqual = function areTooltipsEqual(a, b) {
  return a.d === null && b.d === null || a.d && b.d && a.d[UID] === b.d[UID];
};

var stateChangedKeys = function stateChangedKeys(prevState, nextState) {
  var changedKeys = {};

  for (var k in prevState) {
    changedKeys[k] = k === "filters" && !areFiltersEqual(prevState[k], nextState[k]) || k === "tooltip" && !areTooltipsEqual(prevState[k], nextState[k]) || prevState[k] !== nextState[k];
  }

  return changedKeys;
};

var _default = stateChangedKeys;
exports.default = _default;
},{"../constants":"iJA9"}],"TAPd":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _enterView = _interopRequireDefault(require("enter-view"));

var _loadData = _interopRequireDefault(require("./load-data"));

var _constants = _interopRequireDefault(require("./constants"));

var _selectors = require("./selectors");

var _immutableAddRemove = _interopRequireDefault(require("./utils/immutable-add-remove"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _stateCompare = _interopRequireDefault(require("./utils/state-compare"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var CATEGORIES = _constants.default.CATEGORIES,
    UNIT = _constants.default.UNIT,
    ASKED_OF = _constants.default.ASKED_OF,
    ANSWER_TYPE = _constants.default.ANSWER_TYPE,
    UID = _constants.default.UID,
    QUESTION = _constants.default.QUESTION,
    DEFAULT = _constants.default.DEFAULT,
    HOUSING = _constants.default.HOUSING,
    IMMIGRATION = _constants.default.IMMIGRATION,
    AGE_RANGE = _constants.default.AGE_RANGE,
    START_YEAR = _constants.default.START_YEAR,
    END_YEAR = _constants.default.END_YEAR,
    EVENT = _constants.default.EVENT,
    MOBILE_BREAKPT = _constants.default.MOBILE_BREAKPT,
    COLORS = _constants.default.COLORS,
    sortedCategories = _constants.default.sortedCategories,
    years = _constants.default.years,
    answerTypeLookup = _constants.default.answerTypeLookup,
    imageFilesLookup = _constants.default.imageFilesLookup,
    unitReverseLookup = _constants.default.unitReverseLookup;
var firstDraw = true;
var state = {
  dataQuestions: [],
  dataLinks: [],
  dataHistory: [],
  storyMenu: [],
  currentStoryKey: DEFAULT,
  currentStoryStepIndex: 0,
  currentYearInView: years[0],
  filters: [{
    key: CATEGORIES,
    allValues: [],
    selectedValues: []
  }, {
    key: UNIT,
    allValues: [],
    selectedValues: []
  }, {
    key: ANSWER_TYPE,
    allValues: [],
    selectedValues: []
  }, {
    key: ASKED_OF,
    allValues: [],
    selectedValues: []
  }],
  tooltip: {
    x: 0,
    y: 0,
    d: null
  },
  isMobile: window.innerWidth < MOBILE_BREAKPT || _isMobile.default.any(),
  appHeight: 0,
  appWidth: 0,
  isFilterMenuOpen: false
};
var colorScale = d3.scaleOrdinal(COLORS).domain(sortedCategories);

function setState(nextState) {
  // console.log(nextState);
  var prevState = _objectSpread({}, state);

  state = _objectSpread({}, state, {}, nextState);
  update(prevState);
}

function getTooltipOffsetHeight() {
  return Array.from(document.querySelectorAll(".tooltip-offset")).reduce(function (t, v) {
    return t + v.getBoundingClientRect().height;
  }, 0);
}

function resize() {
  setState({
    appHeight: window.innerHeight,
    appWidth: window.innerWidth,
    isMobile: window.innerWidth < MOBILE_BREAKPT || _isMobile.default.any()
  });
}

function init() {
  (0, _loadData.default)(["questions.csv", "links.csv", "storyMenu.json", "history.csv"]).then(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 4),
        rawQuestions = _ref2[0],
        rawLinks = _ref2[1],
        storyMenu = _ref2[2].storyMenu,
        history = _ref2[3];

    rawQuestions.forEach(function (e) {
      if (e.Categories.indexOf(", ") !== -1) {
        e.Categories = "[Multiple]";
      }

      if (e.Categories.indexOf(" - ") !== -1) {
        e.Categories = e.Categories.split(" - ")[0];
      }
    });
    var stack = [];
    history.sort(function (a, b) {
      return d3.ascending(a[START_YEAR], b[START_YEAR]) || d3.ascending(b[END_YEAR], a[END_YEAR]);
    }).forEach(function (e) {
      var i = stack.findIndex(function (s) {
        return s[END_YEAR] < e[START_YEAR] && s[START_YEAR] < e[START_YEAR];
      });
      e.xIndex = i === -1 ? stack.length : i;
      stack[e.xIndex] = e;
    });
    setState({
      storyMenu: storyMenu.map(function (s) {
        return _objectSpread({}, s, {
          steps: s.steps.map(function (p) {
            return _objectSpread({}, p, {
              year: +p.year
            });
          })
        });
      }),
      dataQuestions: rawQuestions.filter(function (e) {
        return e[CATEGORIES] !== "[Admin.]";
      }).sort(function (a, b) {
        return d3.ascending(+a.Year, +b.Year) || d3.ascending(sortedCategories.indexOf(a.Categories), sortedCategories.indexOf(b.Categories));
      }),
      dataLinks: rawLinks,
      dataHistory: history.map(function (d) {
        var _objectSpread2;

        return _objectSpread({}, d, (_objectSpread2 = {}, _defineProperty(_objectSpread2, START_YEAR, +d[START_YEAR]), _defineProperty(_objectSpread2, END_YEAR, +d[END_YEAR]), _objectSpread2));
      }),
      filters: state.filters.map(function (f) {
        var allValues = Array.from(new Set(rawQuestions.filter(function (e) {
          return e[CATEGORIES] !== "[Admin.]";
        }).map(function (d) {
          return d[f.key];
        }).filter(function (d) {
          return !!d;
        }))).sort(function (a, b) {
          return f.key === CATEGORIES ? d3.ascending(sortedCategories.indexOf(a), sortedCategories.indexOf(b)) : d3.ascending(a, b);
        });
        return _objectSpread({}, f, {
          allValues: allValues,
          selectedValues: allValues
        });
      }),
      appHeight: window.innerHeight,
      appWidth: window.innerWidth,
      isMobile: window.innerWidth < MOBILE_BREAKPT || _isMobile.default.any()
    });
  }).catch(console.error);
}

function makeFilterView(isFilterMenuOpen, filters, nodelets, linklets, appHeight, svgWidthlet, yScalelet) {
  d3.select(".story-menu_dropdown").classed("hidden", isFilterMenuOpen);
  d3.select(".interactive__filter-toggle").classed("is-filter-menu-open", isFilterMenuOpen).on("click", function () {
    setState({
      isFilterMenuOpen: !isFilterMenuOpen
    });
  });
  var filtersEl = d3.select(".interactive__filters");
  filtersEl.classed("visible", isFilterMenuOpen);
  var filter = filtersEl.selectAll(".interactive__filters_filter").data(filters, function (d) {
    return d.key;
  }).join("div").attr("class", "interactive__filters_filter").html(function (d) {
    return "<div class='filter-label'>Filter questions by <strong>".concat(d.key.toLowerCase(), "</strong></div>\n      <div class='filter-options'></div>\n      <div class='select-all ").concat(d.selectedValues.length === d.allValues.length ? "disabled" : "", "'>Select All</div>");
  });
  filter.selectAll(".select-all").on("click", function () {
    var d = d3.select(this.parentNode).data()[0];
    var filterIndex = filters.findIndex(function (e) {
      return e.key === d.key;
    });
    setState({
      filters: [].concat(_toConsumableArray(filters.slice(0, filterIndex)), [_objectSpread({}, filters[filterIndex], {
        selectedValues: filters[filterIndex].allValues
      })], _toConsumableArray(filters.slice(filterIndex + 1)))
    });
  });
  filter.select(".filter-options").selectAll(".filter-option").data(function (d, i) {
    return d.allValues.map(function (e) {
      return {
        label: d.key === ANSWER_TYPE ? answerTypeLookup[e] : e,
        value: e,
        selected: !!~d.selectedValues.indexOf(e),
        key: d.key,
        filterIndex: i
      };
    });
  }).join("div").attr("class", "filter-option").classed("selected", function (d) {
    return d.selected;
  }).html(function (d) {
    return "<div>\n      <div class='checkbox' style='background-color:".concat(!d.selected ? "white" : d.key === CATEGORIES ? colorScale(d.label) : "black", ";'></div>\n      ").concat(d.label, "\n      ").concat(d.key === UNIT ? "<img class='icon' src='assets/images/icons/census_unit_".concat(unitReverseLookup[d.label], ".png'>") : d.key === ANSWER_TYPE ? " <img class='icon' src='assets/images/icons/census_qtype_".concat(d.value, ".png' >") : "", "\n      <div class='check-only'>only</div>\n    </div>");
  }).on("click", function (d) {
    // sleight of hand to avoid multiple click events
    var checkOnly = d3.event.toElement.className === "check-only";
    setState({
      filters: [].concat(_toConsumableArray(filters.slice(0, d.filterIndex)), [_objectSpread({}, filters[d.filterIndex], {
        selectedValues: checkOnly ? [d.value] : (0, _immutableAddRemove.default)(filters[d.filterIndex].selectedValues, d.value)
      })], _toConsumableArray(filters.slice(d.filterIndex + 1)))
    });
  });
  var svg = filtersEl.select("svg").attr("height", appHeight - 48).attr("width", svgWidthlet);
  svg.select(".filters_g_years").selectAll("text").data(years).join("text").attr("y", function (d) {
    return yScalelet(d) - 2;
  }).classed("big-font", function (d) {
    return d % 50 === 0;
  }).text(function (d) {
    return d;
  });
  svg.select(".filters_g_years").selectAll("line").attr("class", "underline").data(years).join("line").attr("y1", function (d) {
    return yScalelet(d);
  }).attr("y2", function (d) {
    return yScalelet(d);
  }).attr("x1", 0).attr("x2", svgWidthlet);
  svg.select(".filters_g_links").selectAll(".line").data(linklets, function (d) {
    return d.Source + d.Target;
  }).join("path").attr("d", function (d) {
    return d.svgPath;
  }).attr("stroke-dasharray", function (d) {
    return +d.Target.slice(0, 4) - +d.Source.slice(0, 4) > 10 ? "2 2" : "";
  }).attr("class", "line").classed("inactive", function (d) {
    return !d.inFilter;
  }).attr("stroke", function (d) {
    return colorScale(d.Category);
  });
  svg.select(".filters_g_circles").selectAll("circle.node").data(Array.from(nodelets.values()), function (d) {
    return d.UID;
  }).join("circle").attr("class", "node").attr("r", function (d) {
    return d.r > 10 ? 6 : d.r > 5 ? 4 : 2;
  }).attr("cx", function (d) {
    return d.x;
  }).attr("cy", function (d) {
    return d.y;
  }).attr("fill", function (d) {
    return colorScale(d[CATEGORIES]);
  }).classed("inactive", function (d) {
    return !d.inFilter;
  });
}

var tooltipConstant = function tooltipConstant(r) {
  return r / 2 * Math.sqrt(2) + 8 * Math.sqrt(2);
};

function makeTooltip(_ref3, isMobile, storyKey, svgWidth) {
  var x = _ref3.x,
      y = _ref3.y,
      d = _ref3.d;

  var _d3$select$node$getBo = d3.select(".interactive__svg").node().getBoundingClientRect(),
      svgX = _d3$select$node$getBo.x;

  var color = colorScale(d[CATEGORIES]);
  var imageId = imageFilesLookup[d[UID]];
  var tooltipOffsetHeight = getTooltipOffsetHeight();
  var yMargins = storyKey === DEFAULT ? 16 : 32;
  var flip = x > 0.5 * svgWidth;
  d3.select(".interactive__tooltip").style("top", isMobile ? "auto" : y + tooltipOffsetHeight + yMargins + tooltipConstant(d.r) + d.r + "px").style("left", isMobile ? "0px" : flip ? "auto" : svgX + x + tooltipConstant(d.r) + d.r + "px").style("right", isMobile ? "0px" : flip ? svgX + svgWidth - x + tooltipConstant(d.r) - d.r + "px" : "auto").style("border-color", color).classed("visible", true).classed("flip", flip).html("<div class='interactive__tooltip_tail' style='border-color:".concat(color, ";'></div>\n    <div class='interactive__tooltip_category' style='color:").concat(color, ";'>\n      ").concat(d[CATEGORIES] === "National origin" ? "Nat'l origin" : d[CATEGORIES], "\n      <img class='icon' src='assets/images/icons/census_unit_").concat(unitReverseLookup[d[UNIT]], ".png' >\n      <img class='icon' src='assets/images/icons/census_qtype_").concat(d[ANSWER_TYPE], ".png' >\n    </div>\n    ").concat(d[AGE_RANGE] ? "<div class='interactive__tooltip_category'>By age range (".concat(d[AGE_RANGE], " brackets)</div>") : "", "\n    <div class='interactive__tooltip_question'>\n      ").concat(d[QUESTION], "\n    </div>\n    ").concat(imageId ? "<img class='image-question' src='assets/images/questions/".concat(imageId, "' >") : "", "\n    "));
}

function onEnterView(el) {
  var isEnter = this.direction === "enter";
  var _state = state,
      currentYearInView = _state.currentYearInView,
      currentStoryKey = _state.currentStoryKey,
      currentStoryStepIndex = _state.currentStoryStepIndex,
      isFilterMenuOpen = _state.isFilterMenuOpen;
  var currentStory = (0, _selectors.currentStorySelector)(state);

  var _d3$select$data = d3.select(el).data(),
      _d3$select$data2 = _slicedToArray(_d3$select$data, 1),
      d = _d3$select$data2[0];

  var i = years.indexOf(d);
  var nextStoryStepIndex;

  if (isEnter) {
    // when a new year enters into view
    // advance to the next story step IFF
    // - there is a story
    // - we are not at the end of the story
    // - new year is greater/equal to next story step's year
    nextStoryStepIndex = currentStoryKey !== "" && currentStoryStepIndex !== null && currentStoryStepIndex < currentStory.steps.length - 1 && d >= currentStory.steps[currentStoryStepIndex + 1].year ? currentStoryStepIndex + 1 : currentStoryStepIndex;
  } else {
    // when a year exits view
    // same idea but IFF
    // - we are not at the beginning of the story
    // - exiting year is less than/equal to current story step's year
    nextStoryStepIndex = currentStoryKey !== "" && currentStoryStepIndex !== null && currentStoryStepIndex > 0 && d <= currentStory.steps[currentStoryStepIndex].year ? currentStoryStepIndex - 1 : currentStoryStepIndex;
  }

  var nextYearInView = isEnter ? d : i === 0 ? years[0] : years[i - 1];

  if (isEnter && nextYearInView > currentYearInView || !isEnter && nextYearInView < currentYearInView) {
    // only update state with new year
    // if scrolling has entered a later year
    // or exited an earlier year
    setState(_objectSpread({
      currentYearInView: nextYearInView
    }, nextStoryStepIndex === currentStoryStepIndex ? {} : {
      currentStoryStepIndex: nextStoryStepIndex
    }, {}, isFilterMenuOpen ? {
      isFilterMenuOpen: false
    } : {}));
  }
}

function afterFirstDraw() {
  (0, _enterView.default)({
    selector: ".label",
    enter: onEnterView.bind({
      direction: "enter"
    }),
    exit: onEnterView.bind({
      direction: "exit"
    }),
    offset: 0.5,
    once: false
  });
}

function makeStoryDropdownMenu(storyMenu, currentStoryKey) {
  var dropdown = d3.select(".story-menu_dropdown").on("mousedown", function () {
    if (this === document.activeElement) {
      d3.event.preventDefault();
      this.blur();
    }
  });
  dropdown.selectAll(".story-menu_dropdown_option").data(storyMenu).join("div").attr("class", "story-menu_dropdown_option").classed("selected", function (d) {
    return d.key === currentStoryKey;
  }).text(function (d) {
    return d.label;
  }).on("mousedown", function (d) {
    setState({
      currentStoryKey: d.key,
      currentStoryStepIndex: 0
    });
  });
  d3.select(".interactive__story-restart").on("click", function () {
    setState({
      currentStoryKey: DEFAULT,
      currentStoryStepIndex: 0
    });
  });
}

function drawCirclesAndLinks(links, nodes) {
  d3.select(".interactive_g_links").selectAll(".line").data(links, function (d) {
    return d.Source + d.Target;
  }).join(function (enter) {
    return enter.append("path").attr("class", "line").attr("d", function (d) {
      return d.svgPath;
    }).attr("stroke-dasharray", function () {
      return this.getTotalLength();
    }).attr("stroke-dashoffset", function () {
      return this.getTotalLength();
    }).call(function (e) {
      return e.transition().duration(500).delay(function (d) {
        return (d.indexByYear || 1) * 3;
      }).attr("stroke-dashoffset", 0);
    });
  }, function (update) {
    return update.call(function (u) {
      return u.transition().duration(500).delay(function (d) {
        return (d.indexByYear || 1) * 3;
      }).attr("d", function (d) {
        return d.svgPath;
      }).attr("stroke-dashoffset", 0);
    });
  }, function (exit) {
    return exit.call(function (e) {
      return e.transition().duration(500).delay(function (d) {
        return (d.indexByYear || 1) * 3;
      }).attr("stroke-dashoffset", function () {
        return this.getTotalLength();
      }).remove();
    });
  }).attr("stroke-width", 2).attr("stroke", function (d) {
    return colorScale(d.Category);
  });
  var circles = d3.select(".interactive_g_circles");
  circles.selectAll("circle.node").data(Array.from(nodes.values()), function (d) {
    return d.UID;
  }).join(function (enter) {
    return enter.append("circle").attr("data-id", function (d) {
      return d[UID];
    }).attr("class", "node").attr("cx", function (d) {
      return d.x;
    }).attr("r", 0).call(function (e) {
      return e.transition().duration(500).delay(function (d) {
        return (d.indexByYear || 1) * 3;
      }).attr("r", function (d) {
        return d.r;
      });
    });
  }, function (update) {
    return update.call(function (u) {
      return u.transition().duration(500).delay(function (d) {
        return (d.indexByYear || 1) * 3;
      }).attr("cx", function (d) {
        return d.x;
      }).attr("r", function (d) {
        return d.r;
      });
    });
  }, function (exit) {
    return exit.call(function (e) {
      return e.transition().duration(500).delay(function (d) {
        return (d.indexByYear || 1) * 3;
      }).attr("r", 0).remove();
    });
  }).attr("cy", function (d) {
    return d.y;
  }).attr("fill", function (d) {
    return d["Age range"] ? "url(#stripe)" : colorScale(d[CATEGORIES]);
  }).attr("stroke", function (d) {
    return colorScale(d[CATEGORIES]);
  }).attr("stroke-width", function (d) {
    return d["Age range"] ? 2 : 0;
  }).on("mouseenter", function (d) {
    var _this$getBBox = this.getBBox(),
        x = _this$getBBox.x,
        y = _this$getBBox.y;

    setState({
      tooltip: {
        x: x,
        y: y,
        d: d
      }
    });
  }).on("mouseleave", function () {
    setState({
      tooltip: _objectSpread({}, state.tooltip, {
        d: null
      })
    });
  });
}

function makeLabelsAndStoryStep(yScale, story, storyStepIndex, storyStepYearLookup, yearInView, legendData) {
  var keys = Array.from(storyStepYearLookup.keys());
  var isDefaultStory = story.key === DEFAULT;
  d3.select(".interactive__story-intro").classed("populated", !isDefaultStory).html(story.storyIntro);
  d3.select(".interactive__img").classed("populated", !isDefaultStory).attr("src", story.img && "assets/images/".concat(story.img, ".jpg"));
  d3.select(".interactive__step-start").html(story.key === HOUSING || story.key === IMMIGRATION ? "<img src='assets/images/icons/arrow-down.svg'>Start" : "").on("click", function () {
    d3.select(".interactive__labels .label.year-".concat(story.steps[0].year)).node().scrollIntoView({
      behavior: "smooth",
      block: "center",
      inline: "center"
    });
  });
  d3.select(".interactive__labels").selectAll(".label").data(years).join("div").attr("class", function (d) {
    return "label year-".concat(d);
  }).classed("has-story-step", function (d) {
    return storyStepYearLookup.has(d);
  }).classed("current", function (d) {
    return d === yearInView;
  }) // initialize
  .style("top", function (d) {
    return yScale(d) - 40 + "px";
  }) // vertically center
  .html(function (d) {
    var storyStep = storyStepYearLookup.has(d) ? storyStepYearLookup.get(d) : null;
    var yearLegendData = legendData.get(d);
    return "<div class='year'>".concat(d, "</div>\n      <div class='story-step'>\n        <div class='story-step-header'>\n          ").concat(storyStep && storyStep.label, "\n        </div>\n        <div class='story-step-body'>\n          ").concat(storyStep && storyStep.text, "\n        </div>\n        ").concat(d !== keys[keys.length - 1] ? "<div class='story-step-down'>\n          <img src='assets/images/icons/arrow-down.svg'>\n          Next\n        </div>" : "", "\n        ").concat(d !== keys[0] ? "<div class='story-step-up'>\n          <img src='assets/images/icons/arrow-up.svg'>\n          Back to top\n        </div>" : "", "\n        <div class='step-legend'>\n          ").concat(yearLegendData ? Array.from(yearLegendData.keys()).map(function (k) {
      return "<div class='step-legend-row'>\n                        <div class='step-legend-row-circle' style='background-color:".concat(colorScale(k), ";'></div>\n                        <div class='step-legend-row-term'>").concat(k, "</div>\n                        <div class='step-legend-row-number'>").concat(yearLegendData.get(k), "</div>\n                      </div>");
    }).join("") : "", "\n        </div>\n      </div>\n    ");
  });
  d3.selectAll(".story-step-down").on("click", function () {
    setState({
      currentStoryStepIndex: Math.min(storyStepIndex + 1, story.steps.length - 1)
    });
  });
  d3.selectAll(".story-step-up").on("click", function () {
    d3.select(".interactive__labels .label.year-".concat(years[0])).node().scrollIntoView({
      behavior: "smooth",
      block: "center",
      inline: "center"
    });
  });
}

function makeHistory(dataHistory, yScale) {
  d3.select(".interactive__history").selectAll(".interactive__history_tick").data(d3.range(dataHistory[0][START_YEAR], years[years.length - 1])).join("div").attr("class", "interactive__history_tick").style("top", function (d) {
    return yScale(d) + "px";
  });
  d3.select(".interactive__history").selectAll(".interactive__history_flag").data(dataHistory).join("div").attr("class", "interactive__history_flag").style("top", function (d) {
    return yScale(d[START_YEAR]) + "px";
  }).style("left", function (d) {
    return 10 * d.xIndex + "px";
  }).classed("one-year-only", function (d) {
    return d[START_YEAR] >= d[END_YEAR];
  }).classed("y-offset", function (d) {
    return d[START_YEAR] === 1990 && d[END_YEAR] === 1991 || d[START_YEAR] === 2001 && d[END_YEAR] > 2001;
  }).style("height", function (d) {
    return (d[START_YEAR] >= d[END_YEAR] ? 0 : yScale(d[END_YEAR]) - yScale(d[START_YEAR])) + 2 + "px";
  }).html(function (d) {
    return "<div class='interactive__history_flag_years'>".concat(d[START_YEAR]).concat(d[END_YEAR] > d[START_YEAR] ? " - ".concat(d[END_YEAR]) : "", "</div>\n            <div class='interactive__history_flag_event'>").concat(d[EVENT], "</div>\n      ");
  });
}

function update(prevState) {
  var _state2 = state,
      currentStoryKey = _state2.currentStoryKey,
      currentStoryStepIndex = _state2.currentStoryStepIndex,
      currentYearInView = _state2.currentYearInView,
      filters = _state2.filters,
      dataHistory = _state2.dataHistory,
      appHeight = _state2.appHeight,
      appWidth = _state2.appWidth,
      storyMenu = _state2.storyMenu,
      tooltip = _state2.tooltip,
      isMobile = _state2.isMobile,
      isFilterMenuOpen = _state2.isFilterMenuOpen;
  var svgHeight = 8.333 * appHeight;
  var svgWidth = isMobile ? appWidth : appWidth * (3 / 7);
  var changedKeys = (0, _stateCompare.default)(prevState, state);
  /**
   * STORY NAVIGATION
   */

  if (firstDraw) {
    makeStoryDropdownMenu(storyMenu, currentStoryKey, filters);
  }
  /**
   * NODES
   * LINKS
   */


  var yScale = d3.scaleLinear().domain([years[0], years[years.length - 1]]).range([appHeight / 6, svgHeight - appHeight / 6]);
  var nodes = (0, _selectors.nodesSelector)(state, {
    svgWidth: svgWidth,
    yScale: yScale,
    useCurrentYearFilter: true
  });
  var links = (0, _selectors.linksSelector)(state, {
    svgWidth: svgWidth,
    yScale: yScale,
    useCurrentYearFilter: true
  });
  /**
   * DRAWING VIZ
   */

  if (changedKeys.appHeight || changedKeys.appWidth || changedKeys.isMobile) {
    d3.select(".interactive__svg").attr("height", svgHeight).attr("width", svgWidth);
  }

  if (changedKeys.dataQuestions || changedKeys.dataLinks || changedKeys.filters || changedKeys.appHeight || changedKeys.appWidth || changedKeys.isMobile || changedKeys.currentYearInView) {
    drawCirclesAndLinks(links, nodes);
  }
  /**
   * TOOLTIP
   */


  if (changedKeys.isMobile || changedKeys.tooltip || changedKeys.currentYearInView || changedKeys.appWidth) {
    d3.select(".interactive_g_circles").selectAll("circle.node").classed("active", function (d) {
      return tooltip.d && d[UID] === tooltip.d[UID];
    }).classed("inactive", function (d) {
      return tooltip.d && d[UID] !== tooltip.d[UID];
    });
    d3.select(".interactive_g_links").selectAll("path.line").classed("inactive", function (d) {
      return tooltip.d && d.Source !== tooltip.d[UID] && d.Target !== tooltip.d[UID];
    }); // if user scrolls (mobile) or taps/mouses away,
    // hide tooltip and reset nodes

    if (changedKeys.currentYearInView || !tooltip.d) {
      d3.select(".interactive__tooltip").classed("visible", false);
      d3.select(".interactive_g_links").selectAll("path.line").classed("inactive", false);
      d3.select(".interactive_g_circles").selectAll("circle.node").classed("active", false).classed("inactive", false);
    } else {
      makeTooltip(tooltip, isMobile, currentStoryKey, svgWidth);
    }
  }
  /**
   * STORY STEP
   */


  if (firstDraw || changedKeys.currentStoryKey || changedKeys.currentStoryStepIndex || changedKeys.isMobile || changedKeys.appHeight) {
    var currentStory = (0, _selectors.currentStorySelector)(state);
    var currentStoryStepYearLookup = (0, _selectors.currentStoryStepYearLookupSelector)(state);
    var legendData = (0, _selectors.legendDataSelector)(state);
    makeLabelsAndStoryStep(yScale, currentStory, currentStoryStepIndex, currentStoryStepYearLookup, currentYearInView, legendData);

    if (changedKeys.currentStoryKey) {
      d3.select(".story-menu_dropdown").selectAll(".story-menu_dropdown_option").classed("selected", function (d) {
        return d.key === currentStoryKey;
      });
      d3.select(".interactive__story-intro").node().scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "center"
      });
    } else if (changedKeys.currentStoryStepIndex && !changedKeys.currentYearInView) {
      // only scroll to next story
      // when state change triggered by clicking Next
      // not after scrolling a new year into view
      d3.select(".interactive__labels .label.year-".concat(currentStory.steps[currentStoryStepIndex].year)).node().scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "center"
      });
    }
  }

  if (changedKeys.currentYearInView) {
    d3.selectAll(".annotation").style("opacity", 0);
    d3.select(".interactive__labels").selectAll(".label").classed("current", function (d) {
      return d === currentYearInView;
    });
    d3.select(".interactive__filter-toggle").classed("visible", currentYearInView > years[0]).on("click", function () {
      setState({
        isFilterMenuOpen: !isFilterMenuOpen
      });
    });
  }
  /**
   * HISTORY FLAGS
   * VIZ LABELS
   */


  if (changedKeys.appHeight || changedKeys.isMobile) {
    makeHistory(dataHistory, yScale);
  }
  /**
   * FILTER VIEW
   */


  if (changedKeys.isFilterMenuOpen || changedKeys.filters || changedKeys.appHeight) {
    var yScalelet = d3.scaleLinear().domain([years[0], years[years.length - 1]]).range([10, appHeight - 68]); // header height - 20

    var svgWidthlet = 0.7 * appWidth * (3 / 7); // sync CSS width, margin

    var nodelets = (0, _selectors.nodesSelector)(state, {
      svgWidth: svgWidthlet,
      yScale: yScalelet,
      useCurrentYearFilter: false
    });
    var linklets = (0, _selectors.linksSelector)(state, {
      svgWidth: svgWidthlet,
      yScale: yScalelet,
      useCurrentYearFilter: false
    });
    makeFilterView(isFilterMenuOpen, filters, nodelets, linklets, appHeight, svgWidthlet, yScalelet);
  }

  if (firstDraw) {
    firstDraw = false;
    afterFirstDraw();
  }
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"enter-view":"RZIL","./load-data":"xZJw","./constants":"iJA9","./selectors":"T3Gr","./utils/immutable-add-remove":"UNIr","./utils/is-mobile":"WEtf","./utils/state-compare":"GUzP"}],"v9Q8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var fallbackData = [{
  image: '2018_02_stand-up',
  url: '2018/02/stand-up',
  hed: 'The Structure of Stand-Up Comedy'
}, {
  image: '2018_04_birthday-paradox',
  url: '2018/04/birthday-paradox',
  hed: 'The Birthday Paradox Experiment'
}, {
  image: '2018_11_boy-bands',
  url: '2018/11/boy-bands',
  hed: 'Internet Boy Band Database'
}, {
  image: '2018_08_pockets',
  url: '2018/08/pockets',
  hed: 'Women’s Pockets are Inferior'
}];
var storyData = null;

function loadJS(src, cb) {
  var ref = document.getElementsByTagName('script')[0];
  var script = document.createElement('script');
  script.src = src;
  script.async = true;
  ref.parentNode.insertBefore(script, ref);

  if (cb && typeof cb === 'function') {
    script.onload = cb;
  }

  return script;
}

function loadStories(cb) {
  var request = new XMLHttpRequest();
  var v = Date.now();
  var url = "https://pudding.cool/assets/data/stories.json?v=".concat(v);
  request.open('GET', url, true);

  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText);
      cb(data);
    } else cb(fallbackData);
  };

  request.onerror = function () {
    return cb(fallbackData);
  };

  request.send();
}

function createLink(d) {
  return "\n\t<a class='footer-recirc__article' href='https://pudding.cool/".concat(d.url, "' target='_blank'>\n\t\t<img class='article__img' src='https://pudding.cool/common/assets/thumbnails/640/").concat(d.image, ".jpg' alt='").concat(d.hed, "'>\n\t\t<p class='article__headline'>").concat(d.hed, "</p>\n\t</a>\n\t");
}

function recircHTML() {
  var url = window.location.href;
  var html = storyData.filter(function (d) {
    return !url.includes(d.url);
  }).slice(0, 4).map(createLink).join('');
  d3.select('.pudding-footer .footer-recirc__articles').html(html);
}

function init() {
  loadStories(function (data) {
    storyData = data;
    recircHTML();
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"epB2":[function(require,module,exports) {
"use strict";

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _graphic = _interopRequireDefault(require("./graphic"));

var _footer = _interopRequireDefault(require("./footer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var $body = d3.select("body");
var previousWidth = 0;

function resize() {
  // only do resize on width changes, not height
  // (remove the conditional if you want to trigger on height change)
  var width = $body.node().offsetWidth;

  if (previousWidth !== width) {
    previousWidth = width;

    _graphic.default.resize();
  }
}

function setupStickyHeader() {
  var $header = $body.select("header");

  if ($header.classed("is-sticky")) {
    var $menu = $body.select(".header__menu");
    var $toggle = $body.select(".header__toggle");
    $toggle.on("click", function () {
      var visible = $menu.classed("is-visible");
      $menu.classed("is-visible", !visible);
      $toggle.classed("is-visible", !visible);
    });
  }
}

function init() {
  window.scrollTo(0, 0); // TODO
  // add mobile class to body tag

  $body.classed("is-mobile", _isMobile.default.any()); // setup resize event

  window.addEventListener("resize", (0, _lodash.default)(resize, 150)); // setup sticky header menu

  setupStickyHeader(); // kick off graphic code

  _graphic.default.init(); // load footer stories


  _footer.default.init();
}

init();
},{"lodash.debounce":"or4r","./utils/is-mobile":"WEtf","./graphic":"TAPd","./footer":"v9Q8"}]},{},["epB2"], null)
//# sourceMappingURL=/main.js.map